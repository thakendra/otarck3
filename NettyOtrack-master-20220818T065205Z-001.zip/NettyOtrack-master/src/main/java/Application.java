import config.ConfigurationManager;
import config.Zeromq;
import entities.*;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class Application {
    public static void main(String[] args) {
        ConfigurationManager.parse();
        Database.initConnection();
        Redis.initRedis();
        FirebaseService.init();

        ExecutorService service = Executors.newFixedThreadPool(10);
        service.execute(new ZeroMQ());
        new Server().run();
    }
}
