package initializer;

import decoders.Gps103ProtocolDecoder;
import decoders.TeltonikaProtocolDecoder;
import decoders.frame.CharacterDelimiterFrameDecoder;
import decoders.frame.TeltonikaFrameDecoder;
import decoders.frame.TopTenFrameDecoder;
import decoders.frame.YokayaFrameDecoder;
import handlers.GeofenceHandler;
import handlers.PacketSaver;
import handlers.Responder;
import decoders.TopTenProtocolDecoder;
import decoders.TRVProtocolDecoder;
import io.netty.channel.*;
import io.netty.channel.group.ChannelGroup;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;

import java.net.InetSocketAddress;

public class ServerInitializer extends ChannelInitializer<Channel> {
    private final ChannelGroup group;

    public ServerInitializer(ChannelGroup group){
        this.group = group;
    }


    @Override
    protected void initChannel(Channel ch) throws Exception {
        ChannelPipeline pipeline = ch.pipeline();
        int port = ((InetSocketAddress)ch.localAddress()).getPort();
        switch (port){
            case 8080:
                pipeline.addLast(new TopTenFrameDecoder());
                pipeline.addLast(new TopTenProtocolDecoder());
                break;
            case 8081:
                pipeline.addLast(new YokayaFrameDecoder());
                break;
            case 8083:
//                System.out.printf("Called Here");
                pipeline.addLast(new CharacterDelimiterFrameDecoder(1024, '#'));
                pipeline.addLast(new StringEncoder());
                pipeline.addLast(new StringDecoder());
                pipeline.addLast(new TRVProtocolDecoder());
                break;
            case 8084:
//                System.out.println("Called Here");
                pipeline.addLast(new TeltonikaFrameDecoder());
                pipeline.addLast(new TeltonikaProtocolDecoder());
                break;
            case 8085:
                pipeline.addLast(new CharacterDelimiterFrameDecoder(2048, false, "\r\n", "\n", ";", "*"));
                pipeline.addLast(new StringEncoder());
                pipeline.addLast(new StringDecoder());
                pipeline.addLast(new Gps103ProtocolDecoder());
                break;

        }
        pipeline.addLast(new PacketSaver());
        pipeline.addLast(new Responder());
//        pipeline.addLast(new GeofenceHandler());
//        pipeline.addLast(new ChannelHandler());

    }
}
