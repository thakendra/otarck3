package dao;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;
import dev.morphia.annotations.Property;
import org.bson.types.ObjectId;

@Entity("idles")
public class Idle {
    @Id
    private ObjectId _id;

    @Property("time")
    private String mTime;

    @Property("lat")
    private String mLat;

    @Property("lon")
    private String mLon;

    @Property("imed")
    private String mImed;

    public Idle(String mTime, String mLat, String mLon, String mImed) {
        this.mTime = mTime;
        this.mLat = mLat;
        this.mLon = mLon;
        this.mImed = mImed;
    }
}
