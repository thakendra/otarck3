package dao;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;
import dev.morphia.annotations.Property;
import org.bson.types.ObjectId;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

@Entity("alives")
public class Alive {
    @Id
    private ObjectId _id;

    @Property("imed")
    private String mImed;

    @Property("created_at")
    private String mDateCreated;

    public Alive(String mImed){
        this.mImed = mImed;
        this.mDateCreated = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
                .withZone(ZoneOffset.UTC)
                .format(Instant.now());
    }
}
