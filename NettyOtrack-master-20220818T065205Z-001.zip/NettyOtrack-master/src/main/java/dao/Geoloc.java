package dao;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;
import dev.morphia.annotations.Property;
import org.bson.types.ObjectId;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Entity("geolocs")
public class Geoloc {

    @Id
    private ObjectId _id;

    @Property("imed")
    private String mImed;

    @Property("source")
    private String mSource;

    @Property("date_time")
    private String mDateTime;

    @Property("coordinates")
    private List<String> mCoordinates;

    @Property("speed")
    private Double mSpeed;

    @Property("altitude")
    private Integer mAltitude;

    @Property("direction")
    private Double mDirection;

    @Property("no_of_satellites")
    private Integer mNoOfSatellites;

    @Property("distance_between_packages")
    private Integer mDistanceBetweenPackages;

    @Property("total_distance")
    private Double mTotalDistance;

    @Property("gsm_signal_level")
    private String mGsmSignalLevel;

    @Property("created_at")
    private String mDateCreated;

    public Geoloc(String mImed, String mSource, String mDateTime, List<String> mCoordinates, Double mSpeed, Integer mAltitude, Double mDirection, Integer mNoOfSatellites, Integer mDistanceBetweenPackages, Double mTotalDistance, String mGsmSignalLevel) {
        this.mImed = mImed;
        this.mSource = mSource;
        this.mDateTime = mDateTime;
        this.mCoordinates = mCoordinates;
        this.mSpeed = mSpeed;
        this.mAltitude = mAltitude;
        this.mDirection = mDirection;
        this.mNoOfSatellites = mNoOfSatellites;
        this.mDistanceBetweenPackages = mDistanceBetweenPackages;
        this.mTotalDistance = mTotalDistance;
        this.mGsmSignalLevel = mGsmSignalLevel;
        this.mDateCreated = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
                .withZone(ZoneOffset.UTC)
                .format(Instant.now());
    }

    public Geoloc(ObjectId _id, String mImed, String mSource, String mDateTime, List<String> mCoordinates, Double mSpeed, Integer mAltitude, Double mDirection, Integer mNoOfSatellites, Integer mDistanceBetweenPackages, Double mTotalDistance, String mGsmSignalLevel, String mDateCreated) {
        this._id = _id;
        this.mImed = mImed;
        this.mSource = mSource;
        this.mDateTime = mDateTime;
        this.mCoordinates = mCoordinates;
        this.mSpeed = mSpeed;
        this.mAltitude = mAltitude;
        this.mDirection = mDirection;
        this.mNoOfSatellites = mNoOfSatellites;
        this.mDistanceBetweenPackages = mDistanceBetweenPackages;
        this.mTotalDistance = mTotalDistance;
        this.mGsmSignalLevel = mGsmSignalLevel;
        this.mDateCreated = mDateCreated;
    }
}
