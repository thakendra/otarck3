package dao;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;
import dev.morphia.annotations.Property;
import org.bson.types.ObjectId;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Entity("trips")
public class Trip {
    @Id
    private ObjectId _id;

    @Property("imed")
    private String mImed;

    @Property("date_time")
    private String mDateTime;

    @Property("coordinates")
    private List<String> mCoordinates;

    @Property("speed")
    private Integer mSpeed;

    @Property("altitude")
    private Integer mAltitude;

    @Property("direction")
    private Integer mDirection;

    @Property("no_of_satellites")
    private Integer mNoOfSatellites;

    @Property("start_date_time")
    private String mStartDateTime;

    @Property("start_speed")
    private Integer mStartSpeed;

    @Property("start_altitude")
    private Integer mStartAltitude;

    @Property("start_coordinates")
    private List<String> mStartCoordinates;

    @Property("start_direction")
    private Integer mStartDirection;

    @Property("initial_no_of_satellites")
    private Integer mInitialNoOfSatellites;

    @Property("time_period")
    private String mTimePeriod;

    @Property("distance")
    private String mDistance;

    @Property("max_speed")
    private Integer mMaxSpeed;

    @Property("avg_speed")
    private Integer mAvgSpeed;

    @Property("total_speed_violation_time")
    private Integer mTotalSpeedViolationTime;

    @Property("total_idle_violation_time")
    private String mTotalIdleViolationTime;

    @Property("waiting_time_after_ignition_turned_on")
    private String mWaitingTimeAfterIgnitionTurnedOn;

    @Property("waiting_time_after_ignition_turned_off")
    private String mWaitingTimeAfterIgnitionTurnedOff;

    @Property("total_idle_time")
    private String mTotalIdleTime;

    @Property("gsm_signal_level")
    private String mGsmSignalLevel;

    @Property("created_at")
    private String mCreatedAt;

    public Trip(String mImed, String mDateTime, List<String> mCoordinates, Integer mSpeed, Integer mAltitude, Integer mDirection, Integer mNoOfSatellites, String mStartDateTime, Integer mStartSpeed, Integer mStartAltitude, List<String> mStartCoordinates, Integer mStartDirection, Integer mInitialNoOfSatellites, String mTimePeriod, String mDistance, Integer mMaxSpeed, Integer mAvgSpeed, Integer mTotalSpeedViolationTime, String mTotalIdleViolationTime, String mWaitingTimeAfterIgnitionTurnedOn, String mWaitingTimeAfterIgnitionTurnedOff, String mTotalIdleTime, String mGsmSignalLevel) {
        this.mImed = mImed;
        this.mDateTime = mDateTime;
        this.mCoordinates = mCoordinates;
        this.mSpeed = mSpeed;
        this.mAltitude = mAltitude;
        this.mDirection = mDirection;
        this.mNoOfSatellites = mNoOfSatellites;
        this.mStartDateTime = mStartDateTime;
        this.mStartSpeed = mStartSpeed;
        this.mStartAltitude = mStartAltitude;
        this.mStartCoordinates = mStartCoordinates;
        this.mStartDirection = mStartDirection;
        this.mInitialNoOfSatellites = mInitialNoOfSatellites;
        this.mTimePeriod = mTimePeriod;
        this.mDistance = mDistance;
        this.mMaxSpeed = mMaxSpeed;
        this.mAvgSpeed = mAvgSpeed;
        this.mTotalSpeedViolationTime = mTotalSpeedViolationTime;
        this.mTotalIdleViolationTime = mTotalIdleViolationTime;
        this.mWaitingTimeAfterIgnitionTurnedOn = mWaitingTimeAfterIgnitionTurnedOn;
        this.mWaitingTimeAfterIgnitionTurnedOff = mWaitingTimeAfterIgnitionTurnedOff;
        this.mTotalIdleTime = mTotalIdleTime;
        this.mGsmSignalLevel = mGsmSignalLevel;
        this.mCreatedAt = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
                .withZone(ZoneOffset.UTC)
                .format(Instant.now());
    }
}
