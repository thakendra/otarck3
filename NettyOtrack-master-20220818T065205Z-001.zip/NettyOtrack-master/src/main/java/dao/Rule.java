package dao;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;
import dev.morphia.annotations.Property;
import org.bson.types.ObjectId;

import java.util.List;

public class Rule{

    @Id
    private ObjectId _id;

    @Property("coordinates")
    private List<List<Double>> coordinates;

    @Property("radius")
    private Double radius;

    @Property("condition")
    private String condition;

    @Property("status")
    private String status;

    @Property("name")
    private String name;

    @Property("rule")
    private ObjectId rule;

    @Property("created_by")
    public ObjectId created_by;

    public Rule(){
    }

    public List<List<Double>> getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(List<List<Double>> coordinates) {
        this.coordinates = coordinates;
    }

    public Double getRadius() {
        return radius;
    }

    public void setRadius(Double radius) {
        this.radius = radius;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ObjectId getRule(){
        return rule;
    }
    public void setRule(ObjectId rule){ this.rule = rule; }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectId getCreatedBy() {
        return created_by;
    }

    public void setCreatedBy(ObjectId created_by) {
        this.created_by = created_by;
    }

    @Override
    public String toString() {
        return "Rule{" + "coordinates=" + coordinates + ", radius=" + radius + ", condition='" + condition + '\'' + ", status='" + status + '\'' + ", name='" + name + '\'' + ", rule=" + rule + ", created_by=" + created_by + '}';
    }
}