package dao;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;
import dev.morphia.annotations.Property;
import org.bson.types.ObjectId;

import java.util.List;

@Entity("notifications")
public class Message {

    @Id
    private ObjectId _id;

    @Property("imed")
    private String topic;

    @Property("title")
    private String title;

    @Property("body")
    private String body;

    @Property("coordinates")
    private List<String> current_location;

    @Property("user_id")
    private String userId = "";

    @Property("geofencing")
    private Boolean geoFencing = false;

    public Message(String topic, String title, String body) {
        this.topic = topic;
        this.title = title;
        this.body = body;
    }
    public Message(String topic,String title, String body, List<String> current_location){
        this.topic = topic;
        this.title = title;
        this.body = body;
        this.current_location = current_location;
    }

    public Message(String topic, String title, String body, String userId, Boolean geoFencing){
        this.topic = topic;
        this.title = title;
        this.body = body;
        this.userId = userId;
        this.geoFencing = geoFencing;
    }


    public List<String> getCurrent_location() {
        return current_location;
    }

    public void setCurrent_location(List<String> current_location) {
        this.current_location = current_location;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }


    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getUserId(){return userId;}

    public void setUserId(String userId){
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "Message{" + "topic='" + topic + '\'' + ", title='" + title + '\'' + ", body='" + body + '\'' + ", current_location=" + current_location + ", userId='" + userId + '\'' + ", geoFencing=" + geoFencing + '}';
    }

}
