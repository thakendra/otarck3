package dao;

import dev.morphia.annotations.Embedded;
import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;
import dev.morphia.annotations.Property;
import org.bson.types.ObjectId;

import java.util.List;
import java.util.Map;

@Entity("vehicles")
public class Vehicle {

    @Id
    private ObjectId _id;

    @Property("imed")
    private String mImed;

    @Property("organization")
    private ObjectId mOrganization;

    @Property("customer")
    private ObjectId mCustomer;

    @Property("device_gsm_no")
    private String mDeviceGsmNo;

    @Property("driver")
    private Map<String, String > mDriver;

    @Property("engine_blockage")
    private Boolean mEngineBlockage;

    @Property("engine_status")
    private Boolean mEngineStatus;

    @Property("groups")
    private List<ObjectId> mGroups;

    @Property("last_bill")
    private ObjectId mLastBill;

    @Property("plate_no")
    private String mPlateNo;

    @Property("reactivity_time")
    private Integer mReactivityTime;

    @Property("speed_limit")
    private Integer mSpeedLimit;

    @Property("stand_by_time")
    private Integer mStandByTime;

    @Property("start_km")
    private Integer mStartKm;

    @Property("type_of_notification")
    private String mTypeOfNotification;

    @Property("type_of_service")
    private String mTypeOfService;

    @Property("type_of_vehicle")
    private String mTypeOfVehicle;

    @Property("current_location")
    private List<Double> mCurrentLocation;

    @Property("reactivity")
    private String mReactivity;

    @Property("ignition")
    private String mIgnition;

    @Property("source")
    private String mSource;

    @Property("lst")
    private String mLst;

    @Property("speed")
    private Double mSpeed;

    @Property("heading")
    private Double mHeading;

    @Property("no_of_satellite")
    private Integer mNoOfSatellite;

    @Property("vehicle_name")
    private String mVehicleName;

    @Embedded("rules")
    private List<Rule> mRules;

    public Vehicle(String mImed, ObjectId mOrganization, ObjectId mCustomer, String mDeviceGsmNo, Map<String, String> mDriver, Boolean mEngineBlockage, Boolean mEngineStatus, List<ObjectId> mGroups, ObjectId mLastBill, String mPlateNo, Integer mReactivityTime, Integer mSpeedLimit, Integer mStandByTime, Integer mStartKm, String mTypeOfNotification, String mTypeOfService, String mTypeOfVehicle, List<Double> mCurrentLocation, String mReactivity, String mIgnition, String mSource, String mLst, Double mSpeed, Double mHeading, Integer mNoOfSatellite, String mVehicleName, List<Rule> mRules) {
        this.mImed = mImed;
        this.mOrganization = mOrganization;
        this.mCustomer = mCustomer;
        this.mDeviceGsmNo = mDeviceGsmNo;
        this.mDriver = mDriver;
        this.mEngineBlockage = mEngineBlockage;
        this.mEngineStatus = mEngineStatus;
        this.mGroups = mGroups;
        this.mLastBill = mLastBill;
        this.mPlateNo = mPlateNo;
        this.mReactivityTime = mReactivityTime;
        this.mSpeedLimit = mSpeedLimit;
        this.mStandByTime = mStandByTime;
        this.mStartKm = mStartKm;
        this.mTypeOfNotification = mTypeOfNotification;
        this.mTypeOfService = mTypeOfService;
        this.mTypeOfVehicle = mTypeOfVehicle;
        this.mCurrentLocation = mCurrentLocation;
        this.mReactivity = mReactivity;
        this.mIgnition = mIgnition;
        this.mSource = mSource;
        this.mLst = mLst;
        this.mSpeed = mSpeed;
        this.mHeading = mHeading;
        this.mNoOfSatellite = mNoOfSatellite;
        this.mVehicleName = mVehicleName;
        this.mRules = mRules;
    }

    public Vehicle(){

    }
    public Vehicle(ObjectId _id, String mImed, ObjectId mOrganization, ObjectId mCustomer, String mDeviceGsmNo, Map<String, String> mDriver, Boolean mEngineBlockage, Boolean mEngineStatus, List<ObjectId> mGroups,  ObjectId mLastBill, String mPlateNo, Integer mReactivityTime, Integer mSpeedLimit, Integer mStandByTime, Integer mStartKm, String mTypeOfNotification, String mTypeOfService, String mTypeOfVehicle, List<Double> mCurrentLocation, String mReactivity, String mIgnition, String mSource, String mLst, Double mSpeed, Double mHeading, Integer mNoOfSatellite, String mVehicleName, List<Rule> mRules) {
        this._id = _id;
        this.mImed = mImed;
        this.mOrganization = mOrganization;
        this.mCustomer = mCustomer;
        this.mDeviceGsmNo = mDeviceGsmNo;
        this.mDriver = mDriver;
        this.mEngineBlockage = mEngineBlockage;
        this.mEngineStatus = mEngineStatus;
        this.mGroups = mGroups;

        this.mLastBill = mLastBill;
        this.mPlateNo = mPlateNo;
        this.mReactivityTime = mReactivityTime;
        this.mSpeedLimit = mSpeedLimit;
        this.mStandByTime = mStandByTime;
        this.mStartKm = mStartKm;
        this.mTypeOfNotification = mTypeOfNotification;
        this.mTypeOfService = mTypeOfService;
        this.mTypeOfVehicle = mTypeOfVehicle;
        this.mCurrentLocation = mCurrentLocation;
        this.mReactivity = mReactivity;
        this.mIgnition = mIgnition;
        this.mSource = mSource;
        this.mLst = mLst;
        this.mSpeed = mSpeed;
        this.mHeading = mHeading;
        this.mNoOfSatellite = mNoOfSatellite;
        this.mVehicleName = mVehicleName;
        this.mRules = mRules;
    }

    public String getmImed() {
        return mImed;
    }

    public ObjectId getmOrganization() {
        return mOrganization;
    }

    public ObjectId getmCustomer() {
        return mCustomer;
    }

    public String getmDeviceGsmNo() {
        return mDeviceGsmNo;
    }

    public Map<String, String> getmDriver() {
        return mDriver;
    }

    public Boolean getmEngineBlockage() {
        return mEngineBlockage;
    }

    public Boolean getmEngineStatus() {
        return mEngineStatus;
    }

    public List<ObjectId> getmGroups() {
        return mGroups;
    }

    public ObjectId getmLastBill() {
        return mLastBill;
    }

    public String getmPlateNo() {
        return mPlateNo;
    }

    public Integer getmReactivityTime() {
        return mReactivityTime;
    }

    public Integer getmSpeedLimit() {
        return mSpeedLimit;
    }

    public Integer getmStandByTime() {
        return mStandByTime;
    }

    public Integer getmStartKm() {
        return mStartKm;
    }


    public String getmTypeOfNotification() {
        return mTypeOfNotification;
    }

    public String getmTypeOfService() {
        return mTypeOfService;
    }

    public String getmTypeOfVehicle() {
        return mTypeOfVehicle;
    }

    public List<Double> getmCurrentLocation() {
        return mCurrentLocation;
    }

    public String getmReactivity() {
        return mReactivity;
    }

    public String getmIgnition() {
        return mIgnition;
    }

    public String getmSource() {
        return mSource;
    }

    public String getmLst() {
        return mLst;
    }

    public Double getmSpeed() {
        return mSpeed;
    }

    public Double getmHeading() {
        return mHeading;
    }

    public Integer getmNoOfSatellite() {
        return mNoOfSatellite;
    }

    public String getmVehicleName() {
        return mVehicleName;
    }

    public List<Rule> getmRules() {
        return mRules;
    }

    public void setmImed(String mImed) {
        this.mImed = mImed;
    }

    public void setmOrganization(ObjectId mOrganization) {
        this.mOrganization = mOrganization;
    }

    public void setmCustomer(ObjectId mCustomer) {
        this.mCustomer = mCustomer;
    }

    public void setmDeviceGsmNo(String mDeviceGsmNo) {
        this.mDeviceGsmNo = mDeviceGsmNo;
    }

    public void setmDriver(Map<String, String> mDriver) {
        this.mDriver = mDriver;
    }

    public void setmEngineBlockage(Boolean mEngineBlockage) {
        this.mEngineBlockage = mEngineBlockage;
    }

    public void setmEngineStatus(Boolean mEngineStatus) {
        this.mEngineStatus = mEngineStatus;
    }

    public void setmGroups(List<ObjectId> mGroups) {
        this.mGroups = mGroups;
    }


    public void setmLastBill(ObjectId mLastBill) {
        this.mLastBill = mLastBill;
    }

    public void setmPlateNo(String mPlateNo) {
        this.mPlateNo = mPlateNo;
    }

    public void setmReactivityTime(Integer mReactivityTime) {
        this.mReactivityTime = mReactivityTime;
    }

    public void setmSpeedLimit(Integer mSpeedLimit) {
        this.mSpeedLimit = mSpeedLimit;
    }

    public void setmStandByTime(Integer mStandByTime) {
        this.mStandByTime = mStandByTime;
    }

    public void setmStartKm(Integer mStartKm) {
        this.mStartKm = mStartKm;
    }

    public void setmTypeOfNotification(String mTypeOfNotification) {
        this.mTypeOfNotification = mTypeOfNotification;
    }

    public void setmTypeOfService(String mTypeOfService) {
        this.mTypeOfService = mTypeOfService;
    }

    public void setmTypeOfVehicle(String mTypeOfVehicle) {
        this.mTypeOfVehicle = mTypeOfVehicle;
    }

    public void setmCurrentLocation(List<Double> mCurrentLocation) {
        this.mCurrentLocation = mCurrentLocation;
    }

    public void setmReactivity(String mReactivity) {
        this.mReactivity = mReactivity;
    }

    public void setmIgnition(String mIgnition) {
        this.mIgnition = mIgnition;
    }

    public void setmSource(String mSource) {
        this.mSource = mSource;
    }

    public void setmLst(String mLst) {
        this.mLst = mLst;
    }

    public void setmSpeed(Double mSpeed) {
        this.mSpeed = mSpeed;
    }

    public void setmHeading(Double mHeading) {
        this.mHeading = mHeading;
    }

    public void setmNoOfSatellite(Integer mNoOfSatellite) {
        this.mNoOfSatellite = mNoOfSatellite;
    }

    public void setmVehicleName(String mVehicleName) {
        this.mVehicleName = mVehicleName;
    }

    public void setmRules(List<Rule> mRules) {
        this.mRules = mRules;
    }
}
