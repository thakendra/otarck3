package dao;

import dev.morphia.annotations.Entity;
import dev.morphia.annotations.Id;
import dev.morphia.annotations.Property;
import org.bson.types.ObjectId;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

@Entity("logins")
public class Login {
    @Id
    private ObjectId _id;

    @Property("imed")
    private String mImed;

    @Property("version")
    private String mVersion;

    @Property("software")
    private String mSoftware;

    @Property("created_at")
    private String mDateCreated;

    public Login(String mImed,String mVersion,String mSoftware){
        this.mImed = mImed;
        this.mSoftware = mSoftware;
        this.mDateCreated = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
                .withZone(ZoneOffset.UTC)
                .format(Instant.now());
        this.mVersion = mVersion;
    }

    public Login(String mImed){
        this.mImed = mImed;
        this.mDateCreated = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
                .withZone(ZoneOffset.UTC)
                .format(Instant.now());
    }
}
