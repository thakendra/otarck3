package config;

public class App {
    public static String NAME = "OTrack Tracking Server";
    public static String VERSION = "0.0.0";
    public static String MODE = "development";
}
