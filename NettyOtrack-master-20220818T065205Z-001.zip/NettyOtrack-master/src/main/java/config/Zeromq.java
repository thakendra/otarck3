package config;

public class Zeromq {
     public static String URL = "";
}
