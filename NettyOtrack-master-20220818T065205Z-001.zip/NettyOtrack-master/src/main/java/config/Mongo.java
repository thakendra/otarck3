package config;

public class Mongo {
    public static String SERVER = "";
    public static int PORT = 0;
    public static String NAME = "";
    public static String USERNAME = "";
    public static String DATABASE = "";
    public static String PASSWORD = "";
    public static String URL = "";
}
