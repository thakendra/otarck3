package config;


import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import com.google.gson.JsonPrimitive;
import utils.Logger;
import utils.StringUtil;

import java.io.*;
import java.lang.reflect.Field;

public class ConfigurationManager {
    public static void parse() {
        File jarDir = new File("");
        String configPath = jarDir.getAbsolutePath().concat("/configuration.json");
        Logger.log("Config path from jar is %s", configPath);

        File configFile = new File(configPath);
        InputStream configStream = null;

        if(configFile.exists() && !configFile.isDirectory()){
            Logger.log("Reading configuration from jar folder");
            try {
                configStream = new FileInputStream(configFile);
            }catch (Exception e){
                Logger.log("Can't read file from jar folder");
            }
        } else{
            Logger.log("Reading configuration from classpath");
            configStream = ConfigurationManager.class.getResourceAsStream("/configuration.json");
        }

        if(configStream != null){
            Logger.log("Configuration file present. Loading configuration from the file");
            JsonParser jsonParser = new JsonParser();
            JsonObject configuration = jsonParser.parse(new InputStreamReader(configStream)).getAsJsonObject();
            configuration.entrySet().forEach(input -> {
                String className = StringUtil.capitalize(input.getKey());
                try {
                    String packagifiedClassName = "config" +  '.' +className;
                    Class<?> klass = Class.forName(packagifiedClassName);
                    input.getValue().getAsJsonObject().entrySet().forEach(field -> {
                        String key = field.getKey().toUpperCase();
                        try{
                            Field keyField = klass.getDeclaredField(key);
                            keyField.setAccessible(true);
                            if(field.getValue().isJsonPrimitive()){
                                JsonPrimitive value = field.getValue().getAsJsonPrimitive();
                                if(value.isBoolean()){
                                    keyField.set(klass, value.getAsBoolean());
                                }
                                else if(value.isNumber()){
                                    keyField.set(klass, value.getAsInt());
                                }else{
                                    keyField.set(klass, value.getAsString());
                                }
                            }
                        }catch (NoSuchFieldException | IllegalAccessException e){
                            Logger.log("Field %s not found in %s" , key , className);
                        }
                    });
                }catch (ClassNotFoundException e){
                    Logger.log("%s class was not found", className);
                }
            });
        } else{
            Logger.log("Configuration file not present");
        }
    }
}
