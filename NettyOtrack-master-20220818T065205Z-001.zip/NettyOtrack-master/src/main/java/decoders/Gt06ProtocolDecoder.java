package decoders;

import helper.PatternBuilder;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

import java.nio.charset.Charset;
import java.util.regex.Pattern;

public class Gt06ProtocolDecoder extends ChannelInboundHandlerAdapter {

    private static final Pattern PATTERN_FUEL = new PatternBuilder()
            .text("!AIOIL,")
            .number("d+,")                       // device address
            .number("d+.d+,")                    // output value
            .number("(d+.d+),")                  // temperature
            .expression("[^,]+,")                // version
            .number("dd")                        // back wave
            .number("d")                         // software status code
            .number("d,")                        // hardware status code
            .number("(d+.d+),")                  // measured value
            .expression("[01],")                 // movement status
            .number("d+,")                       // excited wave times
            .number("xx")                        // checksum
            .compile();

//    private Position decodeFuelData(Position position, String sentence) {
//        Parser parser = new Parser(PATTERN_FUEL, sentence);
//        if (!parser.matches()) {
//            return null;
//        }
//
//        position.set(Position.PREFIX_TEMP + 1, parser.nextDouble(0));
//        position.set(Position.KEY_FUEL_LEVEL, parser.nextDouble(0));
//
//        return position;
//    }

    private static final Pattern PATTERN_LOCATION = new PatternBuilder()
            .text("Current position!")
            .number("Lat:([NS])(d+.d+),")        // latitude
            .number("Lon:([EW])(d+.d+),")        // longitude
            .text("Course:").number("(d+.d+),")  // course
            .text("Speed:").number("(d+.d+),")   // speed
            .text("DateTime:")
            .number("(dddd)-(dd)-(dd) +")        // date
            .number("(dd):(dd):(dd)")            // time
            .compile();

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        ByteBuf buf = Unpooled.wrappedBuffer(msg.toString().getBytes());
        System.out.println(buf.toString(Charset.defaultCharset()));
        int header = buf.readShort();
        if(header == 0x7878){
            System.out.println("Header");
        }
        System.out.println(header);
        System.out.println((String)msg);

    }
}
