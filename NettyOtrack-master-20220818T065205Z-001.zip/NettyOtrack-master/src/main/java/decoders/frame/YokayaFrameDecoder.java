package decoders.frame;

import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import packets.YokayaPacket;
import utils.BaseFrameDecoder;
import utils.Constants;

import java.util.List;

public class YokayaFrameDecoder extends BaseFrameDecoder {

//    @Override
//    protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
//        String message = "";
//        StringBuilder stringBuilder = new StringBuilder();
//        Byte i;
//        int index = 0;
//        //while (!in.isReadable());
//
//        while (in.isReadable()){
//            i = in.readByte();
//            //Verify it's a valid character
//            char c =  (char)(i & 0xFF);
//            if(!Constants.VALID_CHARACTERS_LIST.contains(c)){
//                System.out.println("Need to close connection");
//                stringBuilder = new StringBuilder();
//            }
//            else{
//                stringBuilder.append(c);
//                if(i == '#'){
//                    message = stringBuilder.toString();
//                    out.add(message);
//                    return ;
//                }
//            }A
//            while (!in.isReadable());
//        }
//    }

    @Override
    protected Object decode(ChannelHandlerContext ctx, Channel channel, ByteBuf in) throws Exception {
        String message = "";
        StringBuilder stringBuilder = new StringBuilder();
        Byte i;
        int index = 0;
        //while (!in.isReadable());

        while (in.isReadable()){
            i = in.readByte();
            //Verify it's a valid character
            char c =  (char)(i & 0xFF);
            if(!Constants.VALID_CHARACTERS_LIST.contains(c)){
//                System.out.println("Need to close connection");
                stringBuilder = new StringBuilder();
            }
            else{
                stringBuilder.append(c);
                if(i == '#'){
                    message = stringBuilder.toString();
                    System.out.println("HeLLO"+message);
                    return new YokayaPacket(message, Constants.Vendors.YOKAYA);
                }
            }
            //while (!in.isReadable());
        }
        return null;
    }
}
