package decoders.frame;

import helper.Miscellaneous;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import packets.Packet;
import utils.BaseFrameDecoder;

import java.io.ByteArrayOutputStream;

public class TopTenFrameDecoder extends BaseFrameDecoder {

    private static final int MESSAGE_HEADER = 4;

    @Override
    protected Object decode(ChannelHandlerContext ctx, Channel channel, ByteBuf buf) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        while (buf.isReadable()) {
            baos.write(buf.readByte());
        }
        if (buf.readerIndex() >= MESSAGE_HEADER) {
            return Miscellaneous.bytesToHex2(baos.toByteArray());
        }
        return null;
    }

}
