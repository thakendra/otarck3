package decoders;

import helper.DateBuilder;
import helper.Parser;
import helper.PatternBuilder;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import model.Location;

import java.net.SocketAddress;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Gps103ProtocolDecoder extends ChannelInboundHandlerAdapter {
    private int photoPackets = 0;
    private ByteBuf photo;
    private static final Pattern PATTERN = new PatternBuilder()
            .text("imei:")
            .number("(d+),")                     // imei
            .expression("([^,]+),")              // alarm
            .groupBegin()
            .number("(dd)/?(dd)/?(dd) ?")        // local date (yymmdd)
            .number("(dd):?(dd)(?:dd)?,")        // local time (hhmmss)
            .or()
            .number("d*,")
            .groupEnd()
            .expression("([^,]+)?,")             // rfid
            .groupBegin()
            .text("L,,,")
            .number("(x+),,")                    // lac
            .number("(x+),,,")                   // cid
            .or()
            .text("F,")
            .groupBegin()
            .number("(dd)(dd)(dd).d+")           // time utc (hhmmss)
            .or()
            .number("(?:d{1,5}.d+)?")
            .groupEnd()
            .text(",")
            .expression("([AV]),")               // validity
            .expression("([NS]),").optional()
            .number("(d+)(dd.d+),")              // latitude (ddmm.mmmm)
            .expression("([NS]),").optional()
            .expression("([EW]),").optional()
            .number("(d+)(dd.d+),")              // longitude (dddmm.mmmm)
            .expression("([EW])?,").optional()
            .number("(d+.?d*)?").optional()      // speed
            .number(",(d+.?d*)?").optional()     // course
            .number(",(d+.?d*)?").optional()     // altitude
            .number(",([01])?").optional()       // ignition
            .number(",([01])?").optional()       // door
            .groupBegin()
            .number(",(?:(d+.d+)%)?")            // fuel 1
            .number(",(?:(d+.d+)%|d+)?")         // fuel 2
            .groupEnd("?")
            .number(",([-+]?d+)?").optional()    // temperature
            .groupEnd()
            .any()
            .compile();

    private static final Pattern PATTERN_OBD = new PatternBuilder()
            .text("imei:")
            .number("(d+),")                     // imei
            .expression("OBD,")                  // type
            .number("(dd)(dd)(dd)")              // date (yymmdd)
            .number("(dd)(dd)(dd),")             // time (hhmmss)
            .number("(d+)?,")                    // odometer
            .number("(d+.d+)?,")                 // fuel instant
            .number("(d+.d+)?,")                 // fuel average
            .number("(d+)?,")                    // hours
            .number("(d+),")                     // speed
            .number("(d+.?d*%),")                // power load
            .number("(?:([-+]?d+)|[-+]?),")      // temperature
            .number("(d+.?d*%),")                // throttle
            .number("(d+),")                     // rpm
            .number("(d+.d+),")                  // battery
            .number("([^;]*)")                   // dtcs
            .any()
            .compile();

    private static final Pattern PATTERN_ALT = new PatternBuilder()
            .text("imei:")
            .number("(d+),")                     // imei
            .expression("[^,]+,")
            .expression("(?:-+|(.+)),")          // event
            .expression("(?:-+|(.+)),")          // sensor id
            .expression("(?:-+|(.+)),")          // sensor voltage
            .number("(dd)(dd)(dd),")             // time (hhmmss)
            .number("(dd)(dd)(dd),")             // date (ddmmyy)
            .number("(d+),")                     // rssi
            .number("(d),")                      // gps status
            .number("(-?d+.d+),")                // latitude
            .number("(-?d+.d+),")                // longitude
            .number("(d+),")                     // speed
            .number("(d+),")                     // course
            .number("(-?d+),")                   // altitude
            .number("(d+.d+),")                  // hdop
            .number("(d+),")                     // satellites
            .number("([01]),")                   // ignition
            .number("([01]),")                   // charge
            .expression("(?:-+|(.+))")           // error
            .any()
            .compile();

    private String decodeAlarm(String value) {
        if (value.startsWith("T:")) {
            return Location.ALARM_TEMPERATURE;
        } else if (value.startsWith("oil")) {
            return Location.ALARM_FUEL_LEAK;
        }
        switch (value) {
            case "tracker":
                return null;
            case "help me":
                return Location.ALARM_SOS;
            case "low battery":
                return Location.ALARM_LOW_BATTERY;
            case "stockade":
                return Location.ALARM_GEOFENCE;
            case "move":
                return Location.ALARM_MOVEMENT;
            case "speed":
                return Location.ALARM_OVERSPEED;
            case "acc on":
                return Location.ALARM_POWER_ON;
            case "acc off":
                return Location.ALARM_POWER_OFF;
            case "door alarm":
                return Location.ALARM_DOOR;
            case "ac alarm":
                return Location.ALARM_POWER_CUT;
            case "accident alarm":
                return Location.ALARM_ACCIDENT;
            case "sensor alarm":
                return Location.ALARM_SHOCK;
            case "bonnet alarm":
                return Location.ALARM_BONNET;
            case "footbrake alarm":
                return Location.ALARM_FOOT_BRAKE;
            case "DTC":
                return Location.ALARM_FAULT;
            default:
                return null;
        }
    }


    private void decodeRegular(Channel channel, SocketAddress remoteAddress, String sentence) {

        Parser parser = new Parser(PATTERN, sentence);
        if (!parser.matches()) {
//            return null;
        }

        String imei = parser.next();
//        DeviceSession deviceSession = getDeviceSession(channel, remoteAddress, imei);
//        if (deviceSession == null) {
//            return null;
//        }

        Location position = new Location();
//        position.setDeviceId(deviceSession.getDeviceId());

        String alarm = parser.next();
        position.set(Location.KEY_ALARM, decodeAlarm(alarm));
        if (alarm.equals("help me")) {
            if (channel != null) {
                channel.writeAndFlush("**,imei:" + imei + ",E;");
            }
        } else if (alarm.startsWith("vt")) {
            photoPackets = Integer.parseInt(alarm.substring(2));
            photo = Unpooled.buffer();
        } else if (alarm.equals("acc on")) {
            position.set(Location.KEY_IGNITION, true);
        } else if (alarm.equals("acc off")) {
            position.set(Location.KEY_IGNITION, false);
        } else if (alarm.startsWith("T:")) {
            position.set(Location.PREFIX_TEMP + 1, Double.parseDouble(alarm.substring(2)));
        } else if (alarm.startsWith("oil ")) {
            position.set(Location.KEY_FUEL_LEVEL, Double.parseDouble(alarm.substring(4)));
        } else if (!position.getAttributes().containsKey(Location.KEY_ALARM) && !alarm.equals("tracker")) {
            position.set(Location.KEY_EVENT, alarm);
        }

        DateBuilder dateBuilder = new DateBuilder()
                .setDate(parser.nextInt(0), parser.nextInt(0), parser.nextInt(0));

        int localHours = parser.nextInt(0);
        int localMinutes = parser.nextInt(0);

        String rfid = parser.next();
        if (alarm.equals("rfid")) {
            position.set(Location.KEY_DRIVER_UNIQUE_ID, rfid);
        }

        if (parser.hasNext(2)) {

//            getLastLocation(position, null);

//            position.setNetwork(new Network(CellTower.fromLacCid(parser.nextHexInt(0), parser.nextHexInt(0))));

        } else {

            String utcHours = parser.next();
            String utcMinutes = parser.next();

            dateBuilder.setTime(localHours, localMinutes, parser.nextInt(0));

            // Timezone calculation
            if (utcHours != null && utcMinutes != null) {
                int deltaMinutes = (localHours - Integer.parseInt(utcHours)) * 60;
                deltaMinutes += localMinutes - Integer.parseInt(utcMinutes);
                if (deltaMinutes <= -12 * 60) {
                    deltaMinutes += 24 * 60;
                } else if (deltaMinutes > 12 * 60) {
                    deltaMinutes -= 24 * 60;
                }
                dateBuilder.addMinute(-deltaMinutes);
            }
            position.setTime(dateBuilder.getDate());

            position.setValid(parser.next().equals("A"));
            position.setFixTime(position.getDeviceTime());
            position.setLatitude(parser.nextCoordinate(Parser.CoordinateFormat.HEM_DEG_MIN_HEM));
            position.setLongitude(parser.nextCoordinate(Parser.CoordinateFormat.HEM_DEG_MIN_HEM));
            position.setSpeed(parser.nextDouble(0));
            position.setCourse(parser.nextDouble(0));
            position.setAltitude(parser.nextDouble(0));

            if (parser.hasNext()) {
                position.set(Location.KEY_IGNITION, parser.nextInt() == 1);
            }
            if (parser.hasNext()) {
                position.set(Location.KEY_DOOR, parser.nextInt() == 1);
            }
            position.set("fuel1", parser.nextDouble());
            position.set("fuel2", parser.nextDouble());
            position.set(Location.PREFIX_TEMP + 1, parser.nextInt());
            System.out.println(position.toString());

        }

//        return position;
    }
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        String sentence = (String) msg;
        System.out.printf(sentence);
        SocketAddress remoteAddress = ctx.channel().remoteAddress();
        Channel channel = ctx.channel();
        if (sentence.contains("imei:") && sentence.length() <= 30) {
            if (channel != null) {
                channel.writeAndFlush("LOAD");
                Matcher matcher = Pattern.compile("imei:(\\d+),").matcher(sentence);
//                if (matcher.find()) {
//                    getDeviceSession(channel, remoteAddress, matcher.group(1));
//                }
            }
//            return null;
        }

        if (!sentence.isEmpty() && Character.isDigit(sentence.charAt(0))) {
            if (channel != null) {
                channel.writeAndFlush("ON");
            }
            int start = sentence.indexOf("imei:");
            if (start >= 0) {
                sentence = sentence.substring(start);
            } else {
//                return null;
            }
        }
        decodeRegular(channel, remoteAddress, sentence);
//        if (sentence.substring(21, 21 + 2).equals("vr")) {
//            return decodePhoto(channel, remoteAddress, sentence);
//        } else if (sentence.substring(21, 21 + 3).contains("OBD")) {
//            return decodeObd(channel, remoteAddress, sentence);
//        } else if (sentence.endsWith("*")) {
//            return decodeAlternative(channel, remoteAddress, sentence);
//        } else {
//
//        }
//        super.channelRead(ctx, msg);
    }
}
