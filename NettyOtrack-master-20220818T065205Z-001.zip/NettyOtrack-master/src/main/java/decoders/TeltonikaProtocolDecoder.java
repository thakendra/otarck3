package decoders;

import entities.Redis;
import helper.BitUtil;
import helper.CheckSum;
import helper.UnitsConverter;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import model.Location;
import packets.YokayaPacket;
import utils.Constants;
import utils.LocationUtils;

import java.net.SocketAddress;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class TeltonikaProtocolDecoder extends ChannelInboundHandlerAdapter {


    private static final int IMAGE_PACKET_MAX = 2048;

    private boolean connectionless;
    private boolean extended;
    private Map<Long, ByteBuf> photos = new HashMap<>();

    public void setExtended(boolean extended) {
        this.extended = extended;
    }

//    public TeltonikaProtocolDecoder(Protocol protocol, boolean connectionless) {
//        super(protocol);
//        this.connectionless = connectionless;
//        this.extended = Context.getConfig().getBoolean(getProtocolName() + ".extended");
//    }

    private void parseIdentification(ChannelHandlerContext ctx, ByteBuf buf) throws Exception{

        int length = buf.readUnsignedShort();
        String imei = buf.toString(buf.readerIndex(), length, StandardCharsets.US_ASCII);
        YokayaPacket yp = new YokayaPacket(imei,Constants.Vendors.TELTONIKA,Constants.Yokaya.LOGIN);
        yp.subPacket = yp.new LoginPacket();
        System.out.println("Channel SET=>"+ctx.channel().remoteAddress().toString());
        String previousAddress = Redis.getRedis(imei);
        String currentAddress = ctx.channel().remoteAddress().toString();
        if(previousAddress != null && !currentAddress.equalsIgnoreCase(previousAddress)){
            Redis.remove(previousAddress);
            Redis.remove(imei);
            Redis.storeRedis(imei,ctx.channel().remoteAddress().toString());
            Redis.storeRedis(ctx.channel().remoteAddress().toString(),imei);
        }else if(previousAddress == null){
            Redis.storeRedis(imei,ctx.channel().remoteAddress().toString());
            Redis.storeRedis(ctx.channel().remoteAddress().toString(),imei);
        }

//        DeviceSession deviceSession = getDeviceSession(channel, remoteAddress, imei);
        System.out.println("IMEI=>" + imei);

        if (ctx.channel() != null) {
            ByteBuf response = Unpooled.buffer(1);
            response.writeByte(1);
//            if (deviceSession != null) {
//                response.writeByte(1);
//            } else {
//                response.writeByte(0);
//            }
            ctx.channel().writeAndFlush(response);
//            channel.writeAndFlush(new NetworkMessage(response, remoteAddress));
        }
        super.channelRead(ctx,yp);
    }

    public static final int CODEC_GH3000 = 0x07;
    public static final int CODEC_8 = 0x08;
    public static final int CODEC_8_EXT = 0x8E;
    public static final int CODEC_12 = 0x0C;
    public static final int CODEC_16 = 0x10;


    private void sendImageRequest(Channel channel, SocketAddress remoteAddress, long id, int offset, int size) {
        if (channel != null) {
            ByteBuf response = Unpooled.buffer();
            response.writeInt(0);
            response.writeShort(0);
            response.writeShort(19); // length
            response.writeByte(CODEC_12);
            response.writeByte(1); // nod
            response.writeByte(0x0D); // camera
            response.writeInt(11); // payload length
            response.writeByte(2); // command
            response.writeInt((int) id);
            response.writeInt(offset);
            response.writeShort(size);
            response.writeByte(1); // nod
            response.writeShort(0);
            response.writeShort(CheckSum.crc16(
                    CheckSum.CRC16_IBM, response.nioBuffer(8, response.readableBytes() - 10)));
//            channel.writeAndFlush(new NetworkMessage(response, remoteAddress));
        }
    }

    private void decodeSerial(Channel channel, SocketAddress remoteAddress, Location position, ByteBuf buf) {

//        getLastLocation(position, null);

        int type = buf.readUnsignedByte();
        if (type == 0x0D) {

            buf.readInt(); // length
            int subtype = buf.readUnsignedByte();
            if (subtype == 0x01) {

                long photoId = buf.readUnsignedInt();
                ByteBuf photo = Unpooled.buffer(buf.readInt());
                photos.put(photoId, photo);
                sendImageRequest(
                        channel, remoteAddress, photoId,
                        0, Math.min(IMAGE_PACKET_MAX, photo.capacity()));

            } else if (subtype == 0x02) {

                long photoId = buf.readUnsignedInt();
                buf.readInt(); // offset
                ByteBuf photo = photos.get(photoId);
                photo.writeBytes(buf, buf.readUnsignedShort());
                if (photo.writableBytes() > 0) {
                    sendImageRequest(
                            channel, remoteAddress, photoId,
                            photo.writerIndex(), Math.min(IMAGE_PACKET_MAX, photo.writableBytes()));
                } else {
//                    String uniqueId = Context.getIdentityManager().getById(position.getDeviceId()).getUniqueId();
//                    photos.remove(photoId);
//                    try {
//                        position.set(Location.KEY_IMAGE, Context.getMediaManager().writeFile(uniqueId, photo, "jpg"));
//                    } finally {
//                        photo.release();
//                    }
                }

            }

        } else {

            position.set(Location.KEY_TYPE, type);

            int length = buf.readInt();
            boolean readable = true;
            for (int i = 0; i < length; i++) {
                byte b = buf.getByte(buf.readerIndex() + i);
                if (b < 32 && b != '\r' && b != '\n') {
                    readable = false;
                    break;
                }
            }

            if (readable) {
                String data = buf.readSlice(length).toString(StandardCharsets.US_ASCII).trim();
                if (data.startsWith("UUUUww") && data.endsWith("SSS")) {
                    String[] values = data.substring(6, data.length() - 4).split(";");
                    for (int i = 0; i < 8; i++) {
                        position.set("axle" + (i + 1), Double.parseDouble(values[i]));
                    }
                    position.set("loadTruck", Double.parseDouble(values[8]));
                    position.set("loadTrailer", Double.parseDouble(values[9]));
                    position.set("totalTruck", Double.parseDouble(values[10]));
                    position.set("totalTrailer", Double.parseDouble(values[11]));
                } else {
                    position.set(Location.KEY_RESULT, data);
                }
            } else {
                position.set(Location.KEY_RESULT, ByteBufUtil.hexDump(buf.readSlice(length)));
            }
        }
    }

    private long readValue(ByteBuf buf, int length, boolean signed) {
        switch (length) {
            case 1:
                return signed ? buf.readByte() : buf.readUnsignedByte();
            case 2:
                return signed ? buf.readShort() : buf.readUnsignedShort();
            case 4:
                return signed ? buf.readInt() : buf.readUnsignedInt();
            default:
                return buf.readLong();
        }
    }

    private void decodeOtherParameter(Location position, int id, ByteBuf buf, int length) {
        System.out.println("ID=>"+id);
        switch (id) {
            case 1:
            case 2:
            case 3:
            case 4:
                position.set("di" + id, readValue(buf, length, false));
                break;
            case 9:
                position.set(Location.PREFIX_ADC + 1, readValue(buf, length, false));
                break;
            case 10:
                position.set(Location.PREFIX_ADC + 2, readValue(buf, length, false));
                break;
            case 17:
                position.set("axisX", readValue(buf, length, true));
                break;
            case 18:
                position.set("axisY", readValue(buf, length, true));
                break;
            case 19:
                position.set("axisZ", readValue(buf, length, true));
                break;
            case 21:
                position.set(Location.KEY_RSSI, readValue(buf, length, false));
                break;
            case 25:
            case 26:
            case 27:
            case 28:
                position.set(Location.PREFIX_TEMP + (id - 24), readValue(buf, length, true) * 0.1);
                break;
            case 66:
                position.set(Location.KEY_POWER, readValue(buf, length, false) * 0.001);
                break;
            case 67:
                position.set(Location.KEY_BATTERY, readValue(buf, length, false) * 0.001);
                break;
            case 69:
                position.set("gpsStatus", readValue(buf, length, false));
                break;
            case 72:
            case 73:
            case 74:
                position.set(Location.PREFIX_TEMP + (id - 71), readValue(buf, length, true) * 0.1);
                break;
            case 78:
                long driverUniqueId = readValue(buf, length, false);
                if (driverUniqueId != 0) {
                    position.set(Location.KEY_DRIVER_UNIQUE_ID, String.format("%016X", driverUniqueId));
                }
                break;
            case 80:
                position.set("workMode", readValue(buf, length, false));
                break;
            case 129:
            case 130:
            case 131:
            case 132:
            case 133:
            case 134:
                String driver = id == 129 || id == 132 ? "" : position.getString("driver1");
                position.set("driver" + (id >= 132 ? 2 : 1),
                        driver + buf.readSlice(length).toString(StandardCharsets.US_ASCII).trim());
                break;
            case 179:
                position.set(Location.PREFIX_OUT + 1, readValue(buf, length, false) == 1);
                break;
            case 180:
                position.set(Location.PREFIX_OUT + 2, readValue(buf, length, false) == 1);
                break;
            case 181:
                position.set(Location.KEY_PDOP, readValue(buf, length, false) * 0.1);
                break;
            case 182:
                position.set(Location.KEY_HDOP, readValue(buf, length, false) * 0.1);
                break;
            case 236:
                if (readValue(buf, length, false) == 1) {
                    position.set(Location.KEY_ALARM, Location.ALARM_OVERSPEED);
                }
                break;
            case 237:
                position.set(Location.KEY_MOTION, readValue(buf, length, false) == 0);
                break;
            case 238:
                switch ((int) readValue(buf, length, false)) {
                    case 1:
                        position.set(Location.KEY_ALARM, Location.ALARM_ACCELERATION);
                        break;
                    case 2:
                        position.set(Location.KEY_ALARM, Location.ALARM_BRAKING);
                        break;
                    case 3:
                        position.set(Location.KEY_ALARM, Location.ALARM_CORNERING);
                        break;
                    default:
                        break;
                }
                break;
            case 239:
                position.set(Location.KEY_IGNITION, readValue(buf, length, false) == 1);
                break;
            case 240:
                position.set(Location.KEY_MOTION, readValue(buf, length, false) == 1);
                break;
            case 241:
                position.set(Location.KEY_OPERATOR, readValue(buf, length, false));
                break;
            default:
                position.set(Location.PREFIX_IO + id, readValue(buf, length, false));
                break;
        }
    }

    private void decodeGh3000Parameter(Location position, int id, ByteBuf buf, int length) {
        switch (id) {
            case 1:
                position.set(Location.KEY_BATTERY_LEVEL, readValue(buf, length, false));
                break;
            case 2:
                position.set("usbConnected", readValue(buf, length, false) == 1);
                break;
            case 5:
                position.set("uptime", readValue(buf, length, false));
                break;
            case 20:
                position.set(Location.KEY_HDOP, readValue(buf, length, false) * 0.1);
                break;
            case 21:
                position.set(Location.KEY_VDOP, readValue(buf, length, false) * 0.1);
                break;
            case 22:
                position.set(Location.KEY_PDOP, readValue(buf, length, false) * 0.1);
                break;
            case 67:
                position.set(Location.KEY_BATTERY, readValue(buf, length, false) * 0.001);
                break;
            case 221:
                position.set("button", readValue(buf, length, false));
                break;
            case 222:
                if (readValue(buf, length, false) == 1) {
                    position.set(Location.KEY_ALARM, Location.ALARM_SOS);
                }
                break;
            case 240:
                position.set(Location.KEY_MOTION, readValue(buf, length, false) == 1);
                break;
            case 244:
                position.set(Location.KEY_ROAMING, readValue(buf, length, false) == 1);
                break;
            default:
                position.set(Location.PREFIX_IO + id, readValue(buf, length, false));
                break;
        }
    }

    private void decodeParameter(Location position, int id, ByteBuf buf, int length, int codec) {
        if (codec == CODEC_GH3000) {
            decodeGh3000Parameter(position, id, buf, length);
        } else {
            decodeOtherParameter(position, id, buf, length);
        }
    }

//    private void decodeNetwork(Location position) {
//        long cid = position.getLong(Location.PREFIX_IO + 205);
//        int lac = position.getInteger(Location.PREFIX_IO + 206);
//        if (cid != 0 && lac != 0) {
//            CellTower cellTower = CellTower.fromLacCid(lac, cid);
//            long operator = position.getInteger(Location.KEY_OPERATOR);
//            if (operator != 0) {
//                cellTower.setOperator(operator);
//            }
//            position.setNetwork(new Network(cellTower));
//        }
//    }

    private int readExtByte(ByteBuf buf, int codec, int... codecs) {
        boolean ext = false;
        for (int c : codecs) {
            if (codec == c) {
                ext = true;
                break;
            }
        }
        if (ext) {
            return buf.readUnsignedShort();
        } else {
            return buf.readUnsignedByte();
        }
    }

    private void decodeLocation(Location position, ByteBuf buf, int codec) {

        int globalMask = 0x0f;

        if (codec == CODEC_GH3000) {

            long time = buf.readUnsignedInt() & 0x3fffffff;
            time += 1167609600; // 2007-01-01 00:00:00

            globalMask = buf.readUnsignedByte();
            if (BitUtil.check(globalMask, 0)) {

                position.setTime(new Date(time * 1000));

                int locationMask = buf.readUnsignedByte();

                if (BitUtil.check(locationMask, 0)) {
                    position.setLatitude(buf.readFloat());
                    position.setLongitude(buf.readFloat());
                }

                if (BitUtil.check(locationMask, 1)) {
                    position.setAltitude(buf.readUnsignedShort());
                }

                if (BitUtil.check(locationMask, 2)) {
                    position.setCourse(buf.readUnsignedByte() * 360.0 / 256);
                }

                if (BitUtil.check(locationMask, 3)) {
                    position.setSpeed(UnitsConverter.knotsFromKph(buf.readUnsignedByte()));
                }

                if (BitUtil.check(locationMask, 4)) {
                    position.set(Location.KEY_SATELLITES, buf.readUnsignedByte());
                }

                if (BitUtil.check(locationMask, 5)) {
//                    CellTower cellTower = CellTower.fromLacCid(buf.readUnsignedShort(), buf.readUnsignedShort());
//
//                    if (BitUtil.check(locationMask, 6)) {
//                        cellTower.setSignalStrength((int) buf.readUnsignedByte());
//                    }
//
//                    if (BitUtil.check(locationMask, 7)) {
//                        cellTower.setOperator(buf.readUnsignedInt());
//                    }

//                    position.setNetwork(new Network(cellTower));

                } else {
                    if (BitUtil.check(locationMask, 6)) {
                        position.set(Location.KEY_RSSI, buf.readUnsignedByte());
                    }
                    if (BitUtil.check(locationMask, 7)) {
                        position.set(Location.KEY_OPERATOR, buf.readUnsignedInt());
                    }
                }

            } else {

//                getLastLocation(position, new Date(time * 1000));

            }

        } else {
            long date = buf.readLong();
            System.out.println(Long.toString(date));
            position.setTime(new Date(date));

            position.set("priority", buf.readUnsignedByte());

            position.setLongitude(buf.readInt() / 10000000.0);
            position.setLatitude(buf.readInt() / 10000000.0);
            position.setAltitude(buf.readShort());
            position.setCourse(buf.readUnsignedShort());

            int satellites = buf.readUnsignedByte();
            position.set(Location.KEY_SATELLITES, satellites);

            position.setValid(satellites != 0);

            position.setSpeed(UnitsConverter.knotsFromKph(buf.readUnsignedShort()));

            position.set(Location.KEY_EVENT, readExtByte(buf, codec, CODEC_8_EXT, CODEC_16));
            if (codec == CODEC_16) {
                buf.readUnsignedByte(); // generation type
            }
            System.out.println(position.toString());
            readExtByte(buf, codec, CODEC_8_EXT); // total IO data records

        }

        // Read 1 byte data
        if (BitUtil.check(globalMask, 1)) {
//            System.out.println("Index1");
            int cnt = readExtByte(buf, codec, CODEC_8_EXT);
//            System.out.println("CountIndex"+cnt);
            for (int j = 0; j < cnt; j++) {
                decodeParameter(position, readExtByte(buf, codec, CODEC_8_EXT, CODEC_16), buf, 1, codec);
            }
        }

        // Read 2 byte data
        if (BitUtil.check(globalMask, 2)) {
//            System.out.println("Index2");
            int cnt = readExtByte(buf, codec, CODEC_8_EXT);
//            System.out.println("CountIndex"+cnt);
            for (int j = 0; j < cnt; j++) {
                decodeParameter(position, readExtByte(buf, codec, CODEC_8_EXT, CODEC_16), buf, 2, codec);
            }
        }

        // Read 4 byte data
        if (BitUtil.check(globalMask, 3)) {
//            System.out.println("Index3");
            int cnt = readExtByte(buf, codec, CODEC_8_EXT);
//            System.out.println("CountIndex"+cnt);
            for (int j = 0; j < cnt; j++) {
                decodeParameter(position, readExtByte(buf, codec, CODEC_8_EXT, CODEC_16), buf, 4, codec);
            }
        }

        // Read 8 byte data
        if (codec == CODEC_8 || codec == CODEC_8_EXT || codec == CODEC_16) {
            int cnt = readExtByte(buf, codec, CODEC_8_EXT);
//            System.out.println("HERE"+cnt);
            for (int j = 0; j < cnt; j++) {
                decodeOtherParameter(position, readExtByte(buf, codec, CODEC_8_EXT, CODEC_16), buf, 8);
            }
        }

        // Read 16 byte data
        if (extended) {
            int cnt = readExtByte(buf, codec, CODEC_8_EXT);
//            System.out.println("Extended"+cnt);
            for (int j = 0; j < cnt; j++) {
                int id = readExtByte(buf, codec, CODEC_8_EXT, CODEC_16);
                position.set(Location.PREFIX_IO + id, ByteBufUtil.hexDump(buf.readSlice(16)));
            }
        }

        // Read X byte data
        if (codec == CODEC_8_EXT) {
            int cnt = buf.readUnsignedShort();
//            System.out.println("XBYTE"+cnt);
            for (int j = 0; j < cnt; j++) {
                int id = buf.readUnsignedShort();
                int length = buf.readUnsignedShort();
                if (id == 256) {
                    position.set(Location.KEY_VIN, buf.readSlice(length).toString(StandardCharsets.US_ASCII));
                } else {
                    position.set(Location.PREFIX_IO + id, ByteBufUtil.hexDump(buf.readSlice(length)));
                }
            }
        }

//        decodeNetwork(position);

    }
    private void parseData(ChannelHandlerContext ctx,ByteBuf buf) throws Exception {
        Channel channel = ctx.channel();
        SocketAddress remoteAddress = ctx.channel().remoteAddress();
        List<Location> positions = new LinkedList<>();

        if (!connectionless) {
            buf.readUnsignedInt(); // data length
        }

        int codec = buf.readUnsignedByte();
//        System.out.println("codec=>" + codec);

        int count = buf.readUnsignedByte();
//        System.out.println("count=>" + count);

        for (int i = 0; i < count; i++) {
            Location position = new Location();
            position.setValid(true);
            if (codec == CODEC_12) {
                decodeSerial(channel, remoteAddress, position, buf);
            } else {
                decodeLocation(position, buf, codec);
            }
            if (!position.getOutdated() || !position.getAttributes().isEmpty()) {
                System.out.println("Added");
                positions.add(position);
            }
        }
        if (channel != null) {
            ByteBuf response = Unpooled.buffer();
            response.writeInt(count);
            channel.writeAndFlush(response);
        }
        System.out.println("Count is : " + count);
        System.out.println("Number of locations is: " + positions.size());
        try{
            for(Location location : positions){
                System.out.println(1);
//            Location location = positions.get(0);
                String deviceId = Redis.getRedis(ctx.channel().remoteAddress().toString());
                System.out.println("Device Id: " + deviceId);
                if (deviceId != null) {
                    location.setDeviceId(deviceId);
                }
                SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyy");
                SimpleDateFormat timeFormat = new SimpleDateFormat("HHmmss");

                Date deviceTime = location.getDeviceTime();
                String date = dateFormat.format(deviceTime);
                String time = timeFormat.format(deviceTime);
                String previousIgnition = Redis.getRedis(deviceId + Constants.STORE.IGNITION);
               // System.out.println();
                System.out.println(previousIgnition);

                String firstLong = Redis.getRedis(deviceId + Constants.STORE.FIRST_LONG);
                String firstLat = Redis.getRedis(deviceId + Constants.STORE.FIRST_LAT);

                Redis.storeRedis(deviceId + Constants.STORE.TRIP_DISTANCE, "0");
                String previousDistance = Redis.getRedis(deviceId + Constants.STORE.TRIP_DISTANCE);
                Redis.storeRedis(deviceId + Constants.STORE.IGNITION, Boolean.toString(location.getBoolean(Location.KEY_IGNITION)));

                String maxSpeed = Redis.getRedis(deviceId + Constants.STORE.MAX_SPEED);
                if(maxSpeed != null && maxSpeed.isEmpty()){
                    Redis.storeRedis(deviceId + Constants.STORE.MAX_SPEED, Integer.toString((int)location.getSpeed()));
                }
                else if(maxSpeed != null && Integer.parseInt(maxSpeed) < location.getSpeed()){
                    Redis.storeRedis(deviceId + Constants.STORE.MAX_SPEED, Integer.toString((int)location.getSpeed()));
                }

                if(previousIgnition != null && firstLat != null && firstLong != null){
                    System.out.println(2);
                    Long distance = LocationUtils.distance(
                            Double.parseDouble(firstLat),
                            location.getLatitude(),
                            Double.parseDouble(firstLong),
                            location.getLongitude(),
                            0,
                            0);
                    if(previousDistance != null){
                        Redis.storeRedis(deviceId+Constants.STORE.TRIP_DISTANCE,Integer.toString(Integer.parseInt(previousDistance)+distance.intValue()));
                    }else{
                        Redis.storeRedis(deviceId+Constants.STORE.TRIP_DISTANCE,Integer.toString(distance.intValue()));
                    }

                    if(Boolean.parseBoolean(previousIgnition) == location.getBoolean(Location.KEY_IGNITION)){
                        if(location.getValid()){
                            super.channelRead(ctx,storeGeoloc(deviceId,date,time,location,Integer.toString(distance.intValue())));
                        }
                    }else if(location.getBoolean(Location.KEY_IGNITION) && !Boolean.parseBoolean(previousIgnition)){
                        if(location.getValid()){
                            super.channelRead(ctx,storeGeoloc(deviceId,date,time,location,Integer.toString(distance.intValue())));
                        }
                        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_DATE,date);
                        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_TIME,time);
                        storeDataRedis(deviceId,location);
                    }else if(!location.getBoolean(Location.KEY_IGNITION) && Boolean.parseBoolean(previousIgnition)){
                        if(location.getValid()){
                            super.channelRead(ctx,storeTrip(deviceId,date,time,location,Redis.getRedis(deviceId+Constants.STORE.TRIP_DISTANCE)));
                            Redis.remove(deviceId+Constants.STORE.TRIP_DISTANCE);
                        }
                    }
                }else{
                    storeInitialDataRedis(deviceId,location);
                }
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }

    }
    public void storeDataRedis(String deviceId,Location location){
        Redis.storeRedis(deviceId+Constants.STORE.FIRST_LAT,Double.toString(location.getLatitude()));
        Redis.storeRedis(deviceId+Constants.STORE.FIRST_LONG,Double.toString(location.getLongitude()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_SPEED,String.valueOf((int)location.getSpeed()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_DIR,String.valueOf((int)location.getCourse()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_SAT_NUMBER,Integer.toString(location.getInteger(Location.KEY_SATELLITES)));
    }
    public void storeInitialDataRedis(String deviceId,Location location){
        Redis.storeRedis(deviceId+Constants.STORE.FIRST_LAT,Double.toString(location.getLatitude()));
        Redis.storeRedis(deviceId+Constants.STORE.FIRST_LONG,Double.toString(location.getLongitude()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_LAT,Double.toString(location.getLatitude()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_LONG,Double.toString(location.getLongitude()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_SPEED,String.valueOf((int)location.getSpeed()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_DIR,String.valueOf((int)location.getCourse()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_SAT_NUMBER,Integer.toString(location.getInteger(Location.KEY_SATELLITES)));
    }

    public YokayaPacket storeGeoloc(String deviceId, String date, String time, Location location,String distance){
        YokayaPacket geoloc = new YokayaPacket(deviceId,Constants.Vendors.TELTONIKA,Constants.Yokaya.GEOLOC);
//        System.out.println("Geoloc Data: ");
//        System.out.println(String.valueOf(((int) location.getSpeed())));
//        System.out.println(String.valueOf(((int) location.getCourse())));
//        System.out.println(Integer.toString(location.getInteger(Location.KEY_SATELLITES)));
//        System.out.println(location.getBoolean(Location.KEY_IGNITION));
        geoloc.subPacket = geoloc.new GeolocPacket(
                date,
                time,
                location.getLatitude(),
                location.getLongitude(),
                String.valueOf(((int) location.getSpeed())),
                String.valueOf(((int) location.getCourse())),
                "0",
                distance,
                Long.toString(Math.round(location.getAltitude())),
                Integer.toString(location.getInteger(Location.KEY_RSSI)),
                location.getBoolean(Location.KEY_IGNITION),
                Integer.toString(location.getInteger(Location.KEY_BATTERY)),
                Integer.toString(location.getInteger(Location.KEY_SATELLITES))
        );
        return geoloc;
    }

    public YokayaPacket storeTrip(String deviceId, String date, String time, Location location, String distance){
        System.out.println("Trip Data: ");
        System.out.println(String.valueOf(((int) location.getSpeed())));
        System.out.println(String.valueOf(((int) location.getCourse())));
        System.out.println(Integer.toString(location.getInteger(Location.KEY_SATELLITES)));
        YokayaPacket trip= new YokayaPacket(deviceId,Constants.Vendors.TELTONIKA,Constants.Yokaya.TRIP);
        trip.subPacket= trip.new TripPacket(
                date,
                time,
                Double.toString(location.getLatitude()),
                Double.toString(location.getLongitude()),
                String.valueOf(((int) location.getSpeed())),
                "0",
                String.valueOf(((int) location.getCourse())),
                Integer.toString(location.getInteger(Location.KEY_SATELLITES)),
                Redis.getRedis(deviceId+Constants.STORE.INITIAL_DATE),
                Redis.getRedis(deviceId+Constants.STORE.INITIAL_TIME),
                Redis.getRedis(deviceId+Constants.STORE.FIRST_LAT),
                Redis.getRedis(deviceId+Constants.STORE.FIRST_LONG),
                Redis.getRedis(deviceId+Constants.STORE.INITIAL_SPEED),
                Redis.getRedis(deviceId+Constants.STORE.INITIAL_DIR),
                "0",
                Redis.getRedis(deviceId+Constants.STORE.INITIAL_SAT_NUMBER),
                Redis.getRedis(deviceId + Constants.STORE.MAX_SPEED),
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                Integer.toString(location.getInteger(Location.KEY_RSSI)),
                distance
        );
        return  trip;
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        ByteBuf buf = (ByteBuf)msg;
        System.out.println("Device Message: " + ByteBufUtil.hexDump(buf));
        decodeTcp(ctx,buf);
    }

    private Object decodeTcp(ChannelHandlerContext ctx, ByteBuf buf) throws Exception {

        if (buf.getUnsignedShort(0) > 0) {
            parseIdentification(ctx,buf);
            buf.release();
        } else {
            buf.skipBytes(4);
            parseData(ctx, buf);
            buf.release();
        }

        return null;
    }
}
