package decoders;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.bytes.ByteArrayDecoder;

import java.util.List;

public class PacketDecoder extends ByteArrayDecoder {
    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) {
        byte[] bytes = new byte[in.readableBytes()];
        in.getBytes(in.readerIndex(),bytes);
        System.out.println(new String(bytes));
//        out.add(new Packet(bytesToHex2(bytes)));
//        System.out.println(in);
//                ByteBuf[] delimiters = new ByteBuf[]{
//                        Unpooled.wrappedBuffer(new byte[] {0x0D,0x0A})
//                };
//                ctx.pipeline().addLast(new TopTenFrameDecoder(119,delimiters));
//                ctx.pipeline().addLast(new TopTenProtocolDecoder());
//                if(in.readableBytes() > 15){
//                    ByteBuf buffer = in.readBytes(15);
//                    out.add(new Packet(buffer.toString(CharsetUtil.US_ASCII)));
////                    out.add(new Packet(new byte[buffer.readableBytes()]));
//                    buffer.clear();
//
//                }
//                if(in.readableBytes() > 5){
//                    ByteBuf buffer = in.readBytes(5);
//                    out.add(new Packet(buffer.toString(CharsetUtil.US_ASCII)));
//                    buffer.clear();
//                    ctx.pipeline().addLast(new PacketHandlers());
//                }

    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {

        System.out.println("Exception");
    }
}
