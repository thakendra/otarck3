package decoders;

import entities.Redis;
import helper.Parser;
import helper.PatternBuilder;
import helper.UnitsConverter;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import model.CellTower;
import model.Location;
import model.Network;
import model.WifiAccessPoint;
import packets.YokayaPacket;
import utils.Constants;
import utils.LocationUtils;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;

public class TRVProtocolDecoder extends ChannelInboundHandlerAdapter {
    private static final Pattern PATTERN = new PatternBuilder()
            .expression("[A-Z]{2,3}")
            .expression("[A-Z]P")
            .number("dd")
            .number("(dd)(dd)(dd)")              // date (yymmdd)
            .expression("([AV])")                // validity
            .number("(dd)(dd.d+)")               // latitude
            .expression("([NS])")
            .number("(ddd)(dd.d+)")              // longitude
            .expression("([EW])")
            .number("(ddd.d)")                   // speed
            .number("(dd)(dd)(dd)")              // time (hhmmss)
            .number("([d.]{6})")                 // course
            .number("(ddd)")                     // gsm
            .number("(ddd)")                     // satellites
            .number("(ddd)")                     // battery
            .number("(d)")                       // acc
            .number("(dd)")                      // arm status
            .number("(dd)")                      // working mode
            .number("(?:[0-2]{3})?,")
            .number("(d+),")                     // mcc
            .number("(d+),")                     // mnc
            .number("(d+),")                     // lac
            .number("(d+)")                      // cell
            .any()
            .compile();

    private static final Pattern PATTERN_HEATRBEAT = new PatternBuilder()
            .expression("[A-Z]{2,3}")
            .text("CP01,")
            .number("(ddd)")                     // gsm
            .number("(ddd)")                     // gps
            .number("(ddd)")                     // battery
            .number("(d)")                       // acc
            .number("(dd)")                      // arm status
            .number("(dd)")                      // working mode
            .groupBegin()
            .number("(ddd)")                     // interval
            .number("d")                         // vibration alarm
            .number("ddd")                       // vibration sensitivity
            .number("d")                         // automatic arm
            .number("dddd")                      // automatic arm time
            .number("(d)")                       // blocked
            .number("(d)")                       // power status
            .number("(d)")                       // movement status
            .groupEnd("?")
            .any()
            .compile();

    private static final Pattern PATTERN_LBS = new PatternBuilder()
            .expression("[A-Z]{2,3}")
            .text("AP02,")
            .expression("[^,]+,")                // language
            .number("[01],")                     // reply
            .number("d+,")                       // cell count
            .number("(d+),")                     // mcc
            .number("(d+),")                     // mnc
            .expression("(")
            .groupBegin()
            .number("d+|")                       // lac
            .number("d+|")                       // cid
            .number("d+,")                       // rssi
            .groupEnd("+")
            .expression(")")
            .number("d+,")                       // wifi count
            .expression("(.*)")                  // wifi
            .compile();

    private Boolean decodeOptionalValue(Parser parser, int activeValue) {
        int value = parser.nextInt();
        if (value != 0) {
            return value == activeValue;
        }
        return null;
    }

    private void decodeCommon(Location position, Parser parser) {

        position.set(Location.KEY_RSSI, parser.nextInt());
        position.set(Location.KEY_SATELLITES, parser.nextInt());
        position.set(Location.KEY_BATTERY, parser.nextInt());
        position.set(Location.KEY_IGNITION, decodeOptionalValue(parser, 1));
        position.set(Location.KEY_ARMED, decodeOptionalValue(parser, 1));
        System.out.println("RSSI Key =>" +position.getInteger(Location.KEY_RSSI));
        System.out.println("SATELLITES => "+ position.getInteger(Location.KEY_SATELLITES));
        System.out.println("Battery +>" + position.getInteger(Location.KEY_BATTERY));
        System.out.println("IGNITION =>" + position.getBoolean(Location.KEY_IGNITION));
        int mode = parser.nextInt();
        if (mode != 0) {
            position.set("mode", mode);
        }
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        String sentence = (String) msg;
        System.out.println(sentence);
        String id = sentence.startsWith("TRV") ? sentence.substring(0, 3) : sentence.substring(0, 2);
        System.out.printf("ID=>"+id);
        String type = sentence.substring(id.length(), id.length() + 4);
        System.out.println("Type=>"+type);

        if (ctx.channel() != null) {
            String responseHeader = id + (char) (type.charAt(0) + 1) + type.substring(1);
            if (type.equals("AP00")) {
                String time = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
                ctx.channel().writeAndFlush(responseHeader + "," + time + ",0#");
            } else if (type.equals("AP14")) {
                ctx.channel().writeAndFlush(responseHeader + ",0.000,0.000#");
            } else {
                ctx.channel().writeAndFlush(responseHeader + "#");
            }
        }
        if (type.equals("AP00")) {
            YokayaPacket yp = new YokayaPacket(sentence.substring(id.length() + type.length()),Constants.Vendors.TRV,Constants.Yokaya.LOGIN);
            yp.subPacket = yp.new LoginPacket();
            System.out.println("Channel SET=>"+ctx.channel().remoteAddress().toString());
            String previousAddress = Redis.getRedis(sentence.substring(id.length() + type.length()));
            String currentAddress = ctx.channel().remoteAddress().toString();
            if(previousAddress != null && !currentAddress.equalsIgnoreCase(previousAddress)){
                Redis.remove(previousAddress);
                Redis.remove(sentence.substring(id.length() + type.length()));
                Redis.storeRedis(sentence.substring(id.length() + type.length()),ctx.channel().remoteAddress().toString());
                Redis.storeRedis(ctx.channel().remoteAddress().toString(),sentence.substring(id.length() + type.length()));
            }else if(previousAddress == null){
                Redis.storeRedis(sentence.substring(id.length() + type.length()),ctx.channel().remoteAddress().toString());
                Redis.storeRedis(ctx.channel().remoteAddress().toString(),sentence.substring(id.length() + type.length()));
            }
            super.channelRead(ctx,yp);
//            getDeviceSession(channel, remoteAddress, sentence.substring(id.length() + type.length()));
//            return null;
        }
        else if (type.equals("CP01")) {

//            YokayaPacket alive = new YokayaPacket()
            System.out.println("Channel ID=>"+ctx.channel().remoteAddress().toString());
            Parser parser = new Parser(PATTERN_HEATRBEAT, sentence);
            if (!parser.matches()) {
//                return null;
            }
            Location location = new Location();
            String deviceId = Redis.getRedis(ctx.channel().remoteAddress().toString());
            if(deviceId != null){
                System.out.println("DeviceID"+deviceId);
                location.setDeviceId(Redis.getRedis(ctx.channel().remoteAddress().toString()));
            }
            decodeCommon(location, parser);
            if (parser.hasNext(3)) {
                location.set(Location.KEY_BLOCKED, decodeOptionalValue(parser, 2));
                location.set(Location.KEY_CHARGE, decodeOptionalValue(parser, 1));
                location.set(Location.KEY_MOTION, decodeOptionalValue(parser, 1));
                System.out.println("KEY_BLOCKED Key =>" +location.getBoolean(Location.KEY_BLOCKED));
                System.out.println("KEY_CHARGE Key =>" +location.getBoolean(Location.KEY_CHARGE));
                System.out.println("KEY_MOTION Key =>" +location.getBoolean(Location.KEY_MOTION));
            }

            YokayaPacket alive = new YokayaPacket(deviceId,Constants.Vendors.TRV,Constants.Yokaya.ALIVE);
            alive.subPacket = alive.new AlivePacket(
                    Integer.toString(location.getInteger(Location.KEY_RSSI)),
                    location.getBoolean(Location.KEY_IGNITION),
                    Integer.toString(location.getInteger(Location.KEY_BATTERY)),
                    Integer.toString(location.getInteger(Location.KEY_SATELLITES)));

            super.channelRead(ctx,alive);

            //            location.setDeviceId(23455667);

//            Position position = new Position(getProtocolName());
//            position.setDeviceId(deviceSession.getDeviceId());

//            getLastLocation(position, null);
//            System.out.println(location.toString());

//            return location;


        } else if (type.equals("AP01") || type.equals("AP10") || type.equals("YP03")) {
            System.out.println("Channel ID=>"+ctx.channel().remoteAddress().toString());
            Parser parser = new Parser(PATTERN, sentence);
            if (!parser.matches()) {
//                return null;
            }
            Location location = new Location();
            String deviceId = Redis.getRedis(ctx.channel().remoteAddress().toString());
            if(deviceId != null){
                System.out.println("DeviceID"+deviceId);
                location.setDeviceId(deviceId);
            }
//            location.setDeviceId(23455667);

//            Position position = new Position(getProtocolName());
//            position.setDeviceId(deviceSession.getDeviceId());

//            DateBuilder dateBuilder = new DateBuilder()
//                    .setDate(parser.nextInt(), parser.nextInt(), parser.nextInt());
            String year = "20"+parser.nextInt().toString();
            String month = parser.nextInt().toString();
            String day = parser.nextInt().toString();
            String date = day+month+year;
            location.setValid(parser.next().equals("A"));
            location.setLatitude(parser.nextCoordinate());
            location.setLongitude(parser.nextCoordinate());
            location.setSpeed(UnitsConverter.knotsFromKph(parser.nextDouble()));
//            System.out.println(parser.nextInt());
            String time = new DecimalFormat("00").format(parser.nextInt()) + new DecimalFormat("00").format(parser.nextInt()).toString() + new DecimalFormat("00").format(parser.nextInt()).toString();
//            String hour = parser.nextInt().toString();
//            String min = parser.nextInt().toString();
//            String sec = parser.nextInt().toString();
////            System.out.println(hour);
//            System.out.println(min);
//            System.out.printf(sec);
            System.out.println(time);
//            dateBuilder.setTime(parser.nextInt(), parser.nextInt(), parser.nextInt());
//            location.setTime(dateBuilder.getDate());

            location.setCourse(parser.nextDouble());

            decodeCommon(location, parser);

            location.setNetwork(new Network(CellTower.from(
                    parser.nextInt(), parser.nextInt(), parser.nextInt(), parser.nextInt())));
            System.out.println(location.toString());

            String previousIgnition = Redis.getRedis(deviceId+Constants.STORE.IGNITION);
            String firstLat = Redis.getRedis(deviceId+Constants.STORE.FIRST_LAT);
            String firstLong = Redis.getRedis(deviceId+Constants.STORE.FIRST_LONG);

            Redis.storeRedis(deviceId+Constants.STORE.TRIP_DISTANCE,"0");
            String previousDistance = Redis.getRedis(deviceId+Constants.STORE.TRIP_DISTANCE);
            Redis.storeRedis(deviceId+Constants.STORE.IGNITION,Boolean.toString(location.getBoolean(Location.KEY_IGNITION)));
            if(previousIgnition != null && firstLat != null && firstLong != null){
                Long distance = LocationUtils.distance(
                        Double.parseDouble(firstLat),
                        location.getLatitude(),
                        Double.parseDouble(firstLong),
                        location.getLongitude(),
                        0,
                        0);
                System.out.println(distance);
                if(previousDistance != null){
                    Redis.storeRedis(deviceId+Constants.STORE.TRIP_DISTANCE,Integer.toString(Integer.parseInt(previousDistance)+distance.intValue()));
                }else{
                    Redis.storeRedis(deviceId+Constants.STORE.TRIP_DISTANCE,Integer.toString(distance.intValue()));
                }

                if(Boolean.parseBoolean(previousIgnition) == location.getBoolean(Location.KEY_IGNITION)){
                    if(location.getValid()){
                        super.channelRead(ctx,storeGeoloc(deviceId,date,time,location,Integer.toString(distance.intValue())));
                    }
                }else if(location.getBoolean(Location.KEY_IGNITION) && !Boolean.parseBoolean(previousIgnition)){
                    if(location.getValid()){
                        super.channelRead(ctx,storeGeoloc(deviceId,date,time,location,Integer.toString(distance.intValue())));
                    }
                    Redis.storeRedis(deviceId+Constants.STORE.INITIAL_DATE,date);
                    Redis.storeRedis(deviceId+Constants.STORE.INITIAL_TIME,time);
                    storeDataRedis(deviceId,location);
                }else if(!location.getBoolean(Location.KEY_IGNITION) && Boolean.parseBoolean(previousIgnition)){
                    if(location.getValid()){
                        super.channelRead(ctx,storeTrip(deviceId,date,time,location,Redis.getRedis(deviceId+Constants.STORE.TRIP_DISTANCE)));
                        Redis.remove(deviceId+Constants.STORE.TRIP_DISTANCE);
                    }
                }
            }else{
                storeInitialDataRedis(deviceId,location);
            }

//            return position;

        } else if (type.equals("AP02")) {
            System.out.println("Channel ID=>"+ctx.channel().remoteAddress().toString());
            Parser parser = new Parser(PATTERN_LBS, sentence);
            if (!parser.matches()) {
//                return null;
            }
//            352121088162027
            Location location = new Location();
            String deviceId = Redis.getRedis(ctx.channel().remoteAddress().toString());
            if(deviceId != null){
                System.out.println("DeviceID"+deviceId);
                location.setDeviceId(Redis.getRedis(ctx.channel().remoteAddress().toString()));
            }
//            location.setDeviceId(23455667);
//            Position position = new Position(getProtocolName());
//            position.setDeviceId(deviceSession.getDeviceId());

//            getLastLocation(position, null);

            int mcc = parser.nextInt();
            int mnc = parser.nextInt();

            Network network = new Network();

            for (String cell : parser.next().split(",")) {
                if (!cell.isEmpty()) {
                    String[] values = cell.split("\\|");
                    network.addCellTower(CellTower.from(
                            mcc, mnc,
                            Integer.parseInt(values[0]),
                            Integer.parseInt(values[1]),
                            Integer.parseInt(values[2])));
                }
            }

            for (String wifi : parser.next().split("&")) {
                if (!wifi.isEmpty()) {
                    String[] values = wifi.split("\\|");
                    network.addWifiAccessPoint(WifiAccessPoint.from(values[1], Integer.parseInt(values[2])));
                }
            }
            location.setNetwork(network);
            System.out.println(location.toString());
//            return position;

        }

//        return null;
    }


    public void storeDataRedis(String deviceId,Location location){
        Redis.storeRedis(deviceId+Constants.STORE.FIRST_LAT,Double.toString(location.getLatitude()));
        Redis.storeRedis(deviceId+Constants.STORE.FIRST_LONG,Double.toString(location.getLongitude()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_SPEED,String.valueOf((int)location.getSpeed()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_DIR,String.valueOf((int)location.getCourse()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_SAT_NUMBER,Integer.toString(location.getInteger(Location.KEY_SATELLITES)));
    }
    public void storeInitialDataRedis(String deviceId,Location location){
        Redis.storeRedis(deviceId+Constants.STORE.FIRST_LAT,Double.toString(location.getLatitude()));
        Redis.storeRedis(deviceId+Constants.STORE.FIRST_LONG,Double.toString(location.getLongitude()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_LAT,Double.toString(location.getLatitude()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_LONG,Double.toString(location.getLongitude()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_SPEED,String.valueOf((int)location.getSpeed()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_DIR,String.valueOf((int)location.getCourse()));
        Redis.storeRedis(deviceId+Constants.STORE.INITIAL_SAT_NUMBER,Integer.toString(location.getInteger(Location.KEY_SATELLITES)));
    }

    public YokayaPacket storeGeoloc(String deviceId, String date, String time, Location location,String distance){
        YokayaPacket geoloc = new YokayaPacket(deviceId,Constants.Vendors.TRV,Constants.Yokaya.GEOLOC);
        geoloc.subPacket = geoloc.new GeolocPacket(
                date,
                time,
                location.getLatitude(),
                location.getLongitude(),
                String.valueOf(((int) location.getSpeed())),
                String.valueOf(((int) location.getCourse())),
                "0",
                distance,
                Long.toString(Math.round(location.getAltitude())),
                Integer.toString(location.getInteger(Location.KEY_RSSI)),
                location.getBoolean(Location.KEY_IGNITION),
                Integer.toString(location.getInteger(Location.KEY_BATTERY)),
                Integer.toString(location.getInteger(Location.KEY_SATELLITES))
        );
        return geoloc;
    }

    public YokayaPacket storeTrip(String deviceId, String date, String time, Location location, String distance){

        YokayaPacket trip= new YokayaPacket(deviceId,Constants.Vendors.TRV,Constants.Yokaya.TRIP);
        trip.subPacket= trip.new TripPacket(
                date,
                time,
                Double.toString(location.getLatitude()),
                Double.toString(location.getLatitude()),
                String.valueOf(((int) location.getSpeed())),
                "0",
                String.valueOf(((int) location.getSpeed())),
                Integer.toString(location.getInteger(Location.KEY_SATELLITES)),
                Redis.getRedis(deviceId+Constants.STORE.INITIAL_DATE),
                Redis.getRedis(deviceId+Constants.STORE.INITIAL_TIME),
                Redis.getRedis(deviceId+Constants.STORE.FIRST_LAT),
                Redis.getRedis(deviceId+Constants.STORE.FIRST_LONG),
                Redis.getRedis(deviceId+Constants.STORE.INITIAL_SPEED),
                Redis.getRedis(deviceId+Constants.STORE.INITIAL_DIR),
                "0",
                Redis.getRedis(deviceId+Constants.STORE.INITIAL_SAT_NUMBER),
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                Integer.toString(location.getInteger(Location.KEY_RSSI)),
                distance
        );
        return  trip;
    }
}
