package decoders;

import helper.*;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.Unpooled;
import io.netty.channel.*;
import io.netty.handler.codec.ByteToMessageDecoder;
import io.netty.handler.codec.MessageToMessageDecoder;
import model.Location;
import packets.Packet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.regex.Pattern;


public class TopTenProtocolDecoder extends ChannelInboundHandlerAdapter {


    private static final Pattern PATTERN = new PatternBuilder()
            .number("(dd)(dd)(dd).?d*,")         // time (hhmmss)
            .expression("([AV]),")               // validity
            .number("(d+)(dd.d+),")              // latitude
            .expression("([NS]),")
            .number("(d+)(dd.d+),")              // longitude
            .expression("([EW]),")
            .number("(d+.?d*)?,")                // speed
            .number("(d+.?d*)?,")                // course
            .number("(dd)(dd)(dd)")              // date (ddmmyy)
            .expression("[^\\|]*")
            .groupBegin()
            .number("|(d+.d+)?")                 // hdop
            .number("|(-?d+.?d*)?")              // altitude
            .number("|(xxxx)?")                  // state
            .groupBegin()
            .number("|(xxxx),(xxxx)")            // adc
            .number(",(xxxx)").optional()
            .number(",(xxxx)").optional()
            .number(",(xxxx)").optional()
            .number(",(xxxx)").optional()
            .number(",(xxxx)").optional()
            .number(",(xxxx)").optional()
            .groupBegin()
            .number("|x{16,20}")                 // cell
            .number("|(xx)")                     // rssi
            .number("|(x{8})")                   // odometer
            .groupBegin()
            .number("|(xx)")                     // satellites
            .text("|")
            .expression("(.*)")                  // driver
            .groupEnd("?")
            .or()
            .number("|(d{1,9})")                 // odometer
            .groupBegin()
            .number("|(x{5,})")                  // rfid
            .groupEnd("?")
            .groupEnd("?")
            .groupEnd("?")
            .groupEnd("?")
            .any()
            .compile();

    private static final Pattern PATTERN_RFID = new PatternBuilder()
            .number("|(dd)(dd)(dd),")            // time (hhmmss)
            .number("(dd)(dd)(dd),")             // date (ddmmyy)
            .number("(d+)(dd.d+),")              // latitude
            .expression("([NS]),")
            .number("(d+)(dd.d+),")              // longitude
            .expression("([EW])")
            .compile();

    private static final Pattern PATTERN_OBD = new PatternBuilder()
            .number("(d+.d+),")                  // battery
            .number("(d+),")                     // rpm
            .number("(d+),")                     // speed
            .number("(d+.d+),")                  // throttle
            .number("(d+.d+),")                  // engine load
            .number("(-?d+),")                   // coolant temp
            .number("(d+.d+),")                  // instantaneous fuel
            .number("(d+.d+),")                  // average fuel
            .number("(d+.d+),")                  // driving range
            .number("(d+.?d*),")                 // odometer
            .number("(d+.d+),")                  // single fuel consumption
            .number("(d+.d+),")                  // total fuel consumption
            .number("(d+),")                     // error code count
            .number("(d+),")                     // hard acceleration count
            .number("(d+)")                      // hard brake count
            .compile();

    private static final Pattern PATTERN_OBDA = new PatternBuilder()
            .number("(d+),")                     // total ignition
            .number("(d+.d+),")                  // total driving time
            .number("(d+.d+),")                  // total idling time
            .number("(d+),")                     // average hot start time
            .number("(d+),")                     // average speed
            .number("(d+),")                     // history highest speed
            .number("(d+),")                     // history highest rpm
            .number("(d+),")                     // total hard acceleration
            .number("(d+)")                      // total hard brake
            .compile();

    public static final int MSG_HEARTBEAT = 0x0001;
    public static final int MSG_LOGIN = 0x5000;
    public static final int MSG_LOGIN_RESPONSE = 0x4000;
    public static final int MSG_TRACK_ON_DEMAND = 0x4101;
    public static final int MSG_TRACK_BY_INTERVAL = 0x4102;
    public static final int MSG_OVERSPEED_LIMIT_SET = 0x4105;
    public static final int MSG_MOVEMENT_ALARM = 0x4106;
    public static final int MSG_SET_GEOFENCE_ALARM_OUT_IN = 0x4107;
    public static final int MSG_INITIALIZATION = 0x4110;
    public static final int MSG_SET_SLEEP_MODE = 0x4113;
    public static final int MSG_OUTPUT_CONTROL = 0x4114;
    public static final int MSG_ARM_DISARM = 0x4116;
    public static final int MSG_SET_INTERVAL_IN_STOP = 0x4126;
    public static final int MSG_LISTEN_MONITOR = 0x4130;
    public static final int MSG_TIME_ZONE = 0x4132;
    public static final int MSG_SET_INITIAL_ODOMETER = 0x4145;
    public static final int MSG_REBOOT_GPS = 0x4902;
    public static final int MSG_SET_HEARTBEAT = 0x5119;
    public static final int MSG_CLEAR_DATA_LOGGER = 0x5503;
    public static final int MSG_GET_FIRMWARE_VERSION = 0x9001;
    public static final int MSG_READ_GPS_INTERVAL = 0x9002;
    public static final int MSG_READ_AUTHORIZATION_RECEIVED = 0x9003;
    public static final int MSG_ALARM = 0x9999;
    public static final int MSG_HEART_BEAT_PACKET = 0x5001;
    public static final int MSG_DESCRIPTION_GPS_PACKET = 0x9955;


    private static void sendResponse(
            Channel channel, SocketAddress remoteAddress, ByteBuf id, int type, ByteBuf msg) {

        if (channel != null) {
            ByteBuf buf = Unpooled.buffer(
                    2 + 2 + id.readableBytes() + 2 + msg.readableBytes() + 2 + 2);

            buf.writeByte('@');
            buf.writeByte('@');
            buf.writeShort(buf.capacity());
            buf.writeBytes(id);
            id.release();
            buf.writeShort(type);
            buf.writeBytes(msg);

            msg.release();
//            if(msg.capacity() > 0) {
//                buf.writeBytes(msg);
//            }
//            msg.release();
            buf.writeShort(CheckSum.crc16(CheckSum.CRC16_CCITT_FALSE, buf.nioBuffer()));
            buf.writeByte('\r');
            buf.writeByte('\n');
            System.out.println("ID");
//            System.out.println(ByteBufUtil.hexDump(id));
            System.out.println(ByteBufUtil.hexDump(buf));
            channel.writeAndFlush(buf);
        }
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        System.out.println("Full");
        String data = (String) msg;
        System.out.println(data);
        Integer command = Integer.valueOf(String.valueOf(Integer.parseInt(data.substring(22,26))),16);
        String id = data.substring(8,22);
        byte[] b = new BigInteger(id,16).toByteArray();
        System.out.println(ByteBufUtil.hexDump(b));
        long idParse = Long.parseLong(id);

        System.out.println(ByteBufUtil.hexDump(Unpooled.wrappedBuffer(longToBytes(idParse))));
//        BigInteger idParse = BigInteger.valueOf(Integer.parseInt(id,16));
//        System.out.println(ByteBufUtil.hexDump(Long.toString(idParse).getBytes()));
//        System.out.println(idParse);
//        ByteBuf id = Unpooled.wrappedBuffer(data.substring(8,22).getBytes());
//        System.out.println(ByteBufUtil.hexDump(id));
            if(command == MSG_LOGIN){
                System.out.println("MSG LOGIN");
                ByteBuf response = Unpooled.wrappedBuffer(new byte[]{0x001});
                sendResponse(ctx.channel(),ctx.channel().remoteAddress(),Unpooled.wrappedBuffer(b),MSG_LOGIN_RESPONSE,response);

            }else if(command == MSG_HEART_BEAT_PACKET){
                System.out.println("HeartBeat Packet");

            }else{
                Location position = new Location();
                if(command == MSG_DESCRIPTION_GPS_PACKET){
                    decodeRegular(position,convertHexToString(data.substring(26,data.length() - 8)));
                }else if(command == MSG_ALARM){
                    position.set(Location.KEY_ALARM,decodeAlarm(convertHexToString(data.substring(26,28))));
                    decodeRegular(position,convertHexToString(data.substring(28,data.length() - 8)));
                }
            }

//            case MSG_LOGIN:
//
//            case MSG_HEART_BEAT_PACKET:
//                System.out.println("HeartBeat Packet");
//                break;
//            case MSG_DESCRIPTION_GPS_PACKET:
//                Location position = new Location();
//                System.out.println(convertHexToString(data.substring(26,data.length() - 8)));
//                System.out.println("GPS Packet Details");
//                decodeRegular(position,convertHexToString(data.substring(26,data.length() - 8)));
//                break;
//            case MSG_ALARM:
//                Location position = new Location();
//                position.set(Location.KEY_ALARM,decodeAlarm(convertHexToString(data.substring(26,28))));
//                decodeRegular(position,convertHexToString(data.substring(28,data.length() - 8)));
//                System.out.println("ALarm");
//                System.out.println(convertHexToString(data.substring(26,data.length() - 8)));
//                break;
//
//        if(MSG_LOGIN == Integer.valueOf(String.valueOf(Integer.parseInt(data.substring(22,26))),16)){
//           ByteBuf response = Unpooled.wrappedBuffer(new byte[]{0x001});
//           sendResponse(ctx.channel(),ctx.channel().remoteAddress(),id,MSG_LOGIN_RESPONSE,response);
//        }else{
//            System.out.println("False");
//        }

//        System.out.println(((Packet)msg).convertHexToString());
//        ByteBuf buf = (ByteBuf) msg;
//        buf.skipBytes(2);
//        buf.readShort();
//        ByteBuf id = buf.readSlice(7);
//        System.out.println("ID=>"+id.toString());
//        int command = buf.readUnsignedShort();
//        if(command == MSG_LOGIN){
//            ByteBuf response = Unpooled.wrappedBuffer(new byte[]{0x001});
//            sendResponse(ctx.channel(),ctx.channel().remoteAddress(),id,MSG_LOGIN_RESPONSE,response);
//        }

    }

//    private  String bytesToHex2(byte[] hashInBytes) {
//
//        StringBuilder sb = new StringBuilder();
//        for (int i = 0; i < hashInBytes.length; i++) {
//            String hex = Integer.toHexString(0xff & hashInBytes[i]);
//            if (hex.length() == 1) sb.append('0');
//            sb.append(hex);
//        }
//        return sb.toString();
//
//    }
    private byte[] convertToBytes(Object object) throws IOException {
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
             ObjectOutput out = new ObjectOutputStream(bos)) {
            out.writeObject(object);
            return bos.toByteArray();
        }
    }

    public byte[] longToBytes(long x) {
        ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES);
        buffer.putLong(x);
        return buffer.array();
    }

    public String convertHexToString(String hex){

        StringBuilder sb = new StringBuilder();
        StringBuilder temp = new StringBuilder();

        //49204c6f7665204a617661 split into two characters 49, 20, 4c...
        for( int i=0; i<hex.length()-1; i+=2 ){

            //grab the hex in pairs
            String output = hex.substring(i, (i + 2));
            //convert hex to decimal
            int decimal = Integer.parseInt(output, 16);
            //convert the decimal to character
            sb.append((char)decimal);

            temp.append(decimal);
        }
        return sb.toString();
    }

    private String decodeAlarm(String value){
//        switch (value){
//            case "01":
//                System.out.println("SOS ALARM");
//                return Location.ALARM_SOS;
//            case "02":
//                System.out.println("Like Broken ALarm");
//                return Location
//
//            case "03":
//                System.out.println("Door open alarm");
//                return Location.ALARM_DOOR;
//
//            case "04":
//                System.out.println("Engine On Alarm");
//
//            case "05":
//                System.out.println("Original triggering Alarm");
//
//            case "10":
//                System.out.println("Low Battery");
//
//            case "11":
//                System.out.println("Over Speed");
//
//            case "12":
//                System.out.println("Movement ");
//
//            case "13":
//                System.out.println("Geo Fence Alarm");
//
//            case "30":
//                System.out.println("Vibration Alarm");
//
//            case "50":
//                System.out.println("Power Tamper Alarm");
//
//            case "052":
//                System.out.println("Veer Report");
//
//            case "60":
//                System.out.println("Fatigue Driver alarm");
//
//            case "71":
//                System.out.println("Crash Alarm(Harsh Braking)");
//
//            case "72":
//                System.out.println("Acceleration Alarm");
//
//            case "73":
//                System.out.println("Turnover ALARM");
//
//            case "74":
//                System.out.println("Idle ALARM");
//
//            case "75":
//                System.out.println("Trailer ALARM");
//
//            case "76":
//                System.out.println("Tire Pressure ALARM");
//
//            case "77":
//                System.out.println("Overload ALARM");
//
//            case "078":
//                System.out.println("High temp  ALARM");
//
//            case "79":
//                System.out.println("Low temp ALARM");
//
//            case "81":
//                System.out.println("fuel loss ALARM");
//
//
//        }
        return value;
    }

    private Location decodeRegular(Location position,String sentence){
        Parser parser = new Parser(PATTERN,sentence);
        if(!parser.matches()){
            return null;
        }
        DateBuilder dateBuilder = new DateBuilder()
                .setTime(parser.nextInt(0), parser.nextInt(0), parser.nextInt(0));

        position.setValid(parser.next().equals("A"));
        position.setLatitude(parser.nextCoordinate());
        position.setLongitude(parser.nextCoordinate());

        if (parser.hasNext()) {
            position.setSpeed(parser.nextDouble(0));
        }

        if (parser.hasNext()) {
            position.setCourse(parser.nextDouble(0));
        }

        dateBuilder.setDateReverse(parser.nextInt(0), parser.nextInt(0), parser.nextInt(0));
        position.setTime(dateBuilder.getDate());

        position.set(Location.KEY_HDOP, parser.nextDouble());

        if (parser.hasNext()) {
            position.setAltitude(parser.nextDouble(0));
        }

        if (parser.hasNext()) {
            int status = parser.nextHexInt();
            for (int i = 1; i <= 5; i++) {
                position.set(Location.PREFIX_OUT + i, BitUtil.check(status, i - 1));
            }
            for (int i = 1; i <= 5; i++) {
                position.set(Location.PREFIX_IN + i, BitUtil.check(status, i - 1 + 8));
            }
        }

        for (int i = 1; i <= 8; i++) {
            position.set(Location.PREFIX_ADC + i, parser.nextHexInt());
        }

        position.set(Location.KEY_RSSI, parser.nextHexInt());
        position.set(Location.KEY_ODOMETER, parser.nextHexLong());
        position.set(Location.KEY_SATELLITES, parser.nextHexInt());
        position.set("driverLicense", parser.next());
        position.set(Location.KEY_ODOMETER, parser.nextLong());
        position.set(Location.KEY_DRIVER_UNIQUE_ID, parser.next());
        System.out.println(position.toString());
        return position;
    }



//    @Override
//    protected void decode(ChannelHandlerContext ctx, Object msg, List out) throws Exception {
//        System.out.println("Got Message :" + msg.toString());
////        ByteBuf buf = (ByteBuf) msg;
////        buf.skipBytes(2);
////        buf.readShort();
////        ByteBuf id = buf.readSlice(7);
////        int command = buf.readUnsignedShort();
////        if(command == MSG_LOGIN){
////            ByteBuf response = Unpooled.wrappedBuffer(new byte[]{0x001});
////            sendResponse(ctx.channel(),ctx.channel().remoteAddress(),id,MSG_LOGIN_RESPONSE,response);
////        }
//    }

//    @Override
//    protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
//        System.out.println("Ijjwal");
//        System.out.println(in);
//    }

//    @Override
//    protected void channelRead0(ChannelHandlerContext ctx, ByteBuf msg) throws Exception {
//        System.out.println( "cmklcd");
//    }
}
