package pojo;

import dao.Rule;

import java.util.List;

public class Rules {
    public List<Rule> rules;

}
