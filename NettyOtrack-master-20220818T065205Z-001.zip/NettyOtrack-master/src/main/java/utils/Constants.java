package utils;

import java.util.Arrays;
import java.util.List;

public class Constants {
    public static Character[] VALID_CHARACTERS = {'_','0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','$',';',',','#','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','-','\r','\n','\0','.','\''};
    public static List<Character> VALID_CHARACTERS_LIST = Arrays.asList(VALID_CHARACTERS);

    public static String FCM_CONFIG_FILE = "/otrack-firebase-firebase-adminsdk-idpvm-35949973b4.json";

    public static class Vendors {
        public static String YOKAYA = "Yokaya";
        public static String TOPTEN = "Topten";
        public static String TRV = "TRV";
        public static String TELTONIKA = "TELTONIKA";
    }

    public static class Yokaya {
        public static String LOGIN = "LOGIN";
        public static String GEOLOC = "GEOLOC";
        public static String TRIP = "TRIP";
        public static String IDLE = "IDLE";
        public static String ALIVE = "ALIVE";
    }


    public static class RedisChannels {
        public static String GEOFENCING = "geofencing";
        public static String RGEOFENCING = "rGeofencing";
    }

    public static class ZeroMQChannels {
        public static String ENGINE_BLOCKAGE = "engine_blockage";
        public static String CONFIGURATION = "configuration";
        public static String GEOFENCING = "geofencing";

    }

    public static class STORE {
        public static String INITIAL_LAT = "initialLat";
        public static String INITIAL_LONG = "initialLong";
        public static String FIRST_LAT = "firstlat";
        public static String SECOND_LAT = "secondlat";
        public static String FIRST_LONG = "firstlong";
        public static String SECOND_LONG = "secondlong";
        public static String INITIAL_ALT = "firstalt";
        public static String FINAL_ALT = "secondalt";
        public static String INITIAL_SAT_NUMBER = "firstsatellitenumber";
        public static String FINAL_SAT_NUMBER = "secondsatellitenumber";
        public static String INITIAL_DIR = "firstdirection";
        public static String FINAL_DIR = "seconddirection";
        public static String INITIAL_DIST = "initialdistance";
        public static String FINAL_DIST = "finaldistance";
        public static String INITIAL_SPEED = "initialSpeed";
        public static String FINAL_SPEED = "finalSpeed";
        public static String MAX_SPEED = "maxSpeed";
        public static String IGNITION = "ignition";
        public static String INITIAL_DATE = "initialDate";
        public static String INITIAL_TIME = "initialTime";
        public static String TRIP_DISTANCE = "tripdistance";

    }
}
