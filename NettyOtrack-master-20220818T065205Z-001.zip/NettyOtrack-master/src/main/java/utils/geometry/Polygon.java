package utils.geometry;
import utils.geometry.Point;

import java.util.ArrayList;
import java.util.List;


/**
 *  Simple Polygon class. It doesn't counters for self intersections. And some weirdly shaped polygons
 *
 *  Valid Polygon Types
 *
 * */
public class Polygon {
    List<Point> polygonPoints = new ArrayList<>();
    int numOfVertex = 0;
    public Polygon(List<Double[]> polygonPoints){
        for(Double[] point: polygonPoints){
            this.polygonPoints.add(new Point(point[0], point[1]));
        }
        numOfVertex = polygonPoints.size();
    }

    /**
     *  Reference:  https://stackoverflow.com/questions/14818567/point-in-polygon-algorithm-giving-wrong-results-sometimes/18190354#18190354
     *  Now go as crazy as you want with the polygon.. It should work
     * @param latitude
     * @param longitude
     * @return
     */
    public boolean contains(double latitude, double longitude){

        Point p1 = polygonPoints.get(0);
        int c = 0;

        for(int i = 1; i <= numOfVertex; i++){
            Point p2 = polygonPoints.get(i % numOfVertex);
            if(longitude > Math.min(p1.longitude, p2.longitude)
                    && longitude <= Math.max(p1.longitude, p2.longitude)
                    && latitude <= Math.max(p1.latitude, p2.latitude)
                    && p1.longitude != p2.longitude){
                double xinters = (longitude - p1.longitude) * (p2.latitude - p1.latitude) / (p2.longitude - p1.longitude) + p1.latitude;
                if(p1.latitude == p2.latitude || latitude <= xinters){
                    c++;
                }
            }
            p1 = p2;
        }

        return c % 2 != 0;
    }

    public boolean contains(Point point){
        return  contains(point.latitude, point.longitude);
    }

    public Point getStartPoint(){
        return polygonPoints.get(0);
    }

}

