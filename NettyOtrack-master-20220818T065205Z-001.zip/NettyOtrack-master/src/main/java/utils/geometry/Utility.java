package utils.geometry;

public class Utility {
    public static double deg2rad(double deg){
        return (deg * (Math.PI / 180.0));
    }
    public static double rad2deg(double rad){
        return Math.abs( rad  * (180.0 / Math.PI));
    }
}

