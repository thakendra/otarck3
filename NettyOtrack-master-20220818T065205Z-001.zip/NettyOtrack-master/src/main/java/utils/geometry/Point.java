package utils.geometry;

import java.text.DecimalFormat;

import static utils.geometry.Utility.deg2rad;
import static java.lang.Math.*;


public class Point {
    double latitude;
    double longitude;

    public Point(double longitude, double latitude) {
        DecimalFormat decimalFormat = new DecimalFormat("#.#######");
        this.latitude = Double.parseDouble(decimalFormat.format(latitude));
        this.longitude = Double.parseDouble( decimalFormat.format(longitude));
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }


    @Override
    public String toString() {
        return "Lng: " + longitude + "\tLat: " + latitude;
    }

    public double distanceTo(Point point){
        long EARTH_RADIUS = 6371000;
        double latFrom = deg2rad(this.latitude);
        double lngFrom = deg2rad(this.longitude);
        double latTo = deg2rad(point.latitude);
        double lngTo = deg2rad(point.longitude);

        double lngDelta = lngTo - lngFrom;
        double latDelta = latTo - latFrom;

        double a = pow(sin(latDelta/2),2.0) + cos(latTo) * cos(latFrom)* pow(sin(lngDelta/2),2.0);
        double angle = 2 * atan2(sqrt(a), sqrt(1-a));
        return angle * EARTH_RADIUS;
    }
}