package utils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class DateTimeUtils {
    public static String convertDateTime(String d, String t){
        if(!(StringUtil.isNullOrEmpty(d) || StringUtil.isNullOrEmpty(t))){
            LocalDate newDate = LocalDate.parse(d, DateTimeFormatter.ofPattern("ddMMyyyy"));
            LocalTime newTime = LocalTime.parse(t,DateTimeFormatter.ofPattern("HHmmss"));
            LocalDateTime dt = LocalDateTime.of(newDate,newTime);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            return formatter.format(dt);
        }
//        LOG.error("Invalid Packets. Convert DAte Time Failed "+ d + " "+ t);
        return null;
    }

    public static String convertToLocalDateTime(String d1,String t1,String d2, String t2){
        if(!(StringUtil.isNullOrEmpty(d1) || StringUtil.isNullOrEmpty(t1) || StringUtil.isNullOrEmpty(d2) || StringUtil.isNullOrEmpty(t2))) {
            LocalDate newDate1 = LocalDate.parse(d1, DateTimeFormatter.ofPattern("ddMMyyyy"));
            LocalTime newTime1 = LocalTime.parse(t1, DateTimeFormatter.ofPattern("HHmmss"));
            LocalDateTime dt1 = LocalDateTime.of(newDate1, newTime1);
            LocalDate newDate2 = LocalDate.parse(d2, DateTimeFormatter.ofPattern("ddMMyyyy"));
            LocalTime newTime2 = LocalTime.parse(t2, DateTimeFormatter.ofPattern("HHmmss"));
            LocalDateTime dt2 = LocalDateTime.of(newDate2, newTime2);

            return Long.toString(Math.abs(ChronoUnit.SECONDS.between(dt2,dt1)));
        }
        return null;
    }

}
