package utils;

import config.App;

import java.time.LocalDateTime;

public class Logger {
    public static void log(String string,Object... objects){
        if(App.MODE.equals("development")) {
            System.out.println(LocalDateTime.now().toString() + ": " + String.format(string,objects));
        }
    }
}
