package utils;

public class StringUtil {
    public static String capitalize(String string){
        return string.substring(0, 1).toUpperCase() + string.substring(1);
    }
    public static boolean isNullOrEmpty(String str) {
        if(str != null && !str.trim().isEmpty())
            return false;
        return true;
    }
}
