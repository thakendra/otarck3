package model;

public interface DatabaseObject {
    Object getMongoObject();
}
