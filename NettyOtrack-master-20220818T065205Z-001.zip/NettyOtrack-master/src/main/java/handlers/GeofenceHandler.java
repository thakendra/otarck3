package handlers;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import dao.Message;
import dao.Rule;
import dao.Vehicle;
import entities.Database;
import entities.FirebaseService;
import entities.Redis;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageDecoder;
import packets.YokayaPacket;
import pojo.Rules;
import redis.clients.jedis.JedisPubSub;
import utils.Constants;
import utils.geometry.Point;
import utils.geometry.Polygon;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class GeofenceHandler extends MessageToMessageDecoder {
    @Override
    protected void decode(ChannelHandlerContext ctx, Object msg, List out) throws Exception {
        System.out.println("In Geofence Handler");
        if (msg instanceof YokayaPacket) {
            Object subpacket = ((YokayaPacket) msg).getSubPacket();
            if (subpacket instanceof YokayaPacket.GeolocPacket) {
                System.out.println("It's a geoloc packet");
                YokayaPacket.GeolocPacket packet = (YokayaPacket.GeolocPacket) subpacket;
                String imed = ((YokayaPacket) msg).getmIMEI();
                String geofenceRules = Redis.jedisPool.getResource().get("g" + imed);
                //System.out.println("From Redis: " + geoloc);
                if (geofenceRules == null) {
                    Redis.jedisPool.getResource().publish(Constants.RedisChannels.GEOFENCING, imed);
                    JedisPubSub subscriber = new JedisPubSub() {
                        @Override
                        public void onMessage(String channel, String message) {
                            super.onMessage(channel, message);
                            System.out.println("Channel message");
                            System.out.println(channel);
                            System.out.println(message);
                            if (message.equals(imed)) {
                                this.unsubscribe();
                                String geofenceRules = Redis.jedisPool.getResource().get("g" + imed);
                                geofenceChecking(ctx, packet, geofenceRules);
                            }
                        }
                    };
                    Redis.jedisPool.getResource().subscribe(subscriber, new String[]{Constants.RedisChannels.RGEOFENCING});
                } else {
                    this.geofenceChecking(ctx, packet, geofenceRules);
                }
            }
        }
    }

    public void geofenceChecking(ChannelHandlerContext ctx, YokayaPacket.GeolocPacket packet, String geofenceRules) {
        System.out.println("geofenceRules are: " + geofenceRules);
        Point vehiclePoint = new Point(packet.getmLon(), packet.getmLat());
        Gson gson = new Gson();
        Vehicle vehicle = Database.vehicleCache.get(packet.getIMEI());

        Rules rulesObject = gson.fromJson(geofenceRules, Rules.class);
        List<Rule> rules = rulesObject.rules;
        boolean toUpdate = false;
        //System.out.println(rules.toString());
        List<Rule> tempRules = new ArrayList<>();
        //long start = System.nanoTime();
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < rules.size(); i++) {
            Rule rule = rules.get(i);
            //System.out.println(rule.toString());
            String status = rule.getStatus();
            String currentStatus = "don't know";
            String condition = rule.getCondition();
            if (rule.getCoordinates().size() > 2) {
                List<Double[]> points = new ArrayList<>();
                for (List<Double> coordinates : rule.getCoordinates()) {
                    Double[] coordinatesArray = new Double[coordinates.size()];
                    coordinatesArray = coordinates.toArray(coordinatesArray);
                    points.add(coordinatesArray);
                }
                Polygon polygon = new Polygon(points);
                currentStatus = polygon.contains(vehiclePoint) ? "in" : "out";
            }

            if (rule.getCoordinates().size() == 1) {
                //Logger.hLog("The rule is circle");

                double radius = rule.getRadius();
                Point rulePoint = new Point(rule.getCoordinates().get(0).get(0), rule.getCoordinates().get(0).get(1));
                double distance = rulePoint.distanceTo(vehiclePoint);
                //Logger.log("Distance: %f and Radius %f", distance, radius);
                currentStatus = distance > radius ? "out" : "in";
            }
            if (currentStatus.equals("don't know")) {
                System.out.println("Invalid rule format");
            } else {
                if (!currentStatus.equals(status)) {
                    // Logger.log("Status Change");
                    toUpdate = true;
                    rules.get(i).setStatus(currentStatus);
                    if (condition.contains(currentStatus)) {
                        String title = "Rule broken";
                        String message = String.format("Your vehicle %s is now %sside of the %s", vehicle.getmPlateNo(), currentStatus, rule.getName());
                        String imed = packet.getIMEI();
                        String topic = rules.get(i).getCreatedBy().toString();

                        Message msg = new Message(imed, title, message, topic, true);
                        CompletableFuture.runAsync(() -> {
                            try {
                                FirebaseService.message(msg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        });
                    }
                }
                tempRules.add(rule);
                //polygon.print();
            }

            if (toUpdate) {
                vehicle.setmRules(tempRules);
                Database.vehicleCache.invalidate(vehicle.getmImed());
                Database.vehicleCache.put(vehicle.getmImed(), vehicle);
            }

        }
    }
}
