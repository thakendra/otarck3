package handlers;

import entities.Redis;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageDecoder;
import packets.YokayaPacket;
import utils.Constants;

import java.util.List;

public class Responder extends MessageToMessageDecoder {
    @Override
    protected void decode(ChannelHandlerContext ctx, Object msg, List out) throws Exception {
        if(msg instanceof YokayaPacket && ((YokayaPacket) msg).vendor.equals(Constants.Vendors.YOKAYA)){
            String message = "ACK," + ((YokayaPacket) msg).getmPacketNo() + ";\n";
            ctx.write(message);
//            System.out.println("Writing message");
            String imei = ((YokayaPacket) msg).getmIMEI();
            String eb = Redis.getRedis("eb"+ imei);
            if(eb != null){
                if(eb.equals("ON")){
                    ctx.write(">OUTPUT,REL1=1;REL2=0");
                }else if(eb.equals("OFF")){
                    ctx.write(">OUTPUT,REL1=0;REL2=0");
                }
                Redis.remove("eb" + imei);
            }
        }

        out.add(msg);
    }
}
