package handlers;

import dao.Vehicle;
import dev.morphia.Datastore;
import entities.Database;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageDecoder;
import model.DatabaseObject;
import packets.Packet;
import packets.YokayaPacket;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class PacketSaver extends MessageToMessageDecoder {
    @Override
    protected void decode(ChannelHandlerContext ctx, Object msg, List out) throws Exception {
//        System.out.println(msg.toString());
//        System.out.println("Called inside Packet Saver");
        if (msg instanceof YokayaPacket) {
            if(((YokayaPacket) msg).subPacket instanceof DatabaseObject){
                Object data = ((DatabaseObject) ((YokayaPacket) msg).subPacket).getMongoObject();
                try{
                    Database.getDatabase().save(data);
//                    System.out.println("Saving Packet");
                }catch (Exception e){
                    e.printStackTrace();
//                    System.out.println("Can't Save packet" +  data.toString());
                }
                Vehicle vehicle = Database.vehicleCache.get(((YokayaPacket) msg).getmIMEI());
                if(vehicle == null) return;
                if(((YokayaPacket) msg).subPacket instanceof YokayaPacket.GeolocPacket){
                    YokayaPacket.GeolocPacket packet = ((YokayaPacket.GeolocPacket) ((YokayaPacket) msg).subPacket);
//                    System.out.println("I am a geoloc packet");
//                    assert vehicle != null;
                    vehicle.setmLst(DateTimeFormatter.ISO_INSTANT
                            .withZone(ZoneOffset.UTC)
                            .format(Instant.now()));
                    List<Double> location = new ArrayList<>();
                    location.add(packet.getmLon());
                    location.add(packet.getmLat());
                    vehicle.setmCurrentLocation(location);
                    vehicle.setmSpeed(packet.getSpeed());
                    vehicle.setmHeading(packet.getHeading());
                    vehicle.setmReactivity("on");
                    if(packet.getIgnition() != null){
                        System.out.println("Ignition is :" + packet.getIgnition().toString());
                        vehicle.setmIgnition(packet.getIgnition()?"on":"off");
                    }
                    Database.vehicleCache.invalidate(vehicle.getmImed());
                    Database.vehicleCache.put(vehicle.getmImed(), vehicle);
//                    System.out.println(vehicle.getmPlateNo());
                }

                if(((YokayaPacket) msg).subPacket instanceof YokayaPacket.AlivePacket){
                    YokayaPacket.AlivePacket packet = ((YokayaPacket.AlivePacket) ((YokayaPacket) msg).subPacket);
//                    System.out.println("I am a Alive packet");
//                    assert vehicle != null;
                    vehicle.setmLst(DateTimeFormatter.ISO_INSTANT
                            .withZone(ZoneOffset.UTC)
                            .format(Instant.now()));
                    vehicle.setmReactivity("on");
                    vehicle.setmSpeed(0.0);
                    vehicle.setmIgnition(packet.getIgnition()?"on":"off");
                    Database.vehicleCache.invalidate(vehicle.getmImed());
                    Database.vehicleCache.put(vehicle.getmImed(), vehicle);
//                    System.out.println(vehicle.getmPlateNo());
                }else{
                    vehicle.setmLst(DateTimeFormatter.ISO_INSTANT
                            .withZone(ZoneOffset.UTC)
                            .format(Instant.now()));
                    Database.vehicleCache.invalidate(vehicle.getmImed());
                    Database.vehicleCache.put(vehicle.getmImed(), vehicle);
                }
            }
            out.add(msg);
        }
    }
}
