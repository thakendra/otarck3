package entities;

import config.Zeromq;
import org.zeromq.SocketType;
import org.zeromq.ZMQ;
import org.zeromq.ZContext;
import utils.Constants;

public class ZeroMQ implements Runnable {
    @Override
    public void run() {
        ZContext context = new ZContext();
        ZMQ.Socket subscriber = context.createSocket(SocketType.SUB);
        subscriber.connect(Zeromq.URL);
        System.out.println("Starting ZeroMQ: " + Zeromq.URL);

        subscriber.subscribe(Constants.ZeroMQChannels.ENGINE_BLOCKAGE);
        subscriber.subscribe(Constants.ZeroMQChannels.CONFIGURATION);
        subscriber.subscribe(Constants.ZeroMQChannels.GEOFENCING);
        while (true){
            String channel = subscriber.recvStr(0).trim();
            String imed = subscriber.recvStr(0).trim();
//            System.out.println("Channel is : " + channel);
//            System.out.println("imed is : " + imed);
            if(channel.equals(Constants.ZeroMQChannels.ENGINE_BLOCKAGE)){
                String status = subscriber.recvStr(0).trim();
//                System.out.println("Status is : " + status);
                Redis.storeRedis("eb"+imed, status);
            }
        }
    }
}
