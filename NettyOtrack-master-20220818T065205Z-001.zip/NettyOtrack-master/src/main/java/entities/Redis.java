package entities;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class Redis {

    public static JedisPool jedisPool = null;

    public static synchronized void initRedis(){
        if(null == jedisPool) {
            try {
                JedisPoolConfig config = new JedisPoolConfig();
                config.setMaxTotal(1000);
                jedisPool = new JedisPool(config, "localhost");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public synchronized static Jedis getJedis() {
        initRedis();
        Jedis jedis = null;
        try {
            if (null != jedisPool) {
                jedis = jedisPool.getResource();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jedis;
    }

    public synchronized static void storeRedis(String key, String value) {
        try {

            Jedis jedis = getJedis();
            jedis.set(key, value);
            jedis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//    public static void storeRedis(String key, String value){
//
//       try {
//           jedisPool.getResource().set(key, value);
//       }catch (Exception e){
//           e.printStackTrace();
//       } finally {
//
//       }
//       jedisPool.close();
//    }

    public synchronized static String getRedis(String key) {
        Jedis jedis = getJedis();
        if (null == jedis) {
            return null;
        }
        String value = jedis.get(key);
        jedis.close();
        return value;
    }

    public synchronized static void remove(String key) {
        try {
            Jedis jedis = getJedis();
            jedis.del(key);
            jedis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//    public static String getRedis(String keys){
//        try{
//            return jedisPool.getResource().get(keys);
//        }catch (Exception e){
//            e.printStackTrace();
//            return null;
//        }
////        return jedisPool.getResource().get(keys);
//    }
}
