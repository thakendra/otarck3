package entities;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.FirebaseMessaging;
import dao.Message;
import com.google.firebase.messaging.Notification;
import org.json.JSONObject;
import utils.Constants;

import javax.xml.crypto.Data;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class FirebaseService {

    //private FirebaseApp firebaseApp;

    public static void init(){

        File jarDir = new File("");
        String configPath = jarDir.getAbsolutePath().concat(Constants.FCM_CONFIG_FILE);
        File configFile = new File(configPath);
        InputStream configStream = null;
        try {
            if (configFile.exists() && !configFile.isDirectory()) {
                configStream = new FileInputStream(configFile);
            } else {
                configStream = FirebaseService.class.getResourceAsStream(Constants.FCM_CONFIG_FILE);
            }

            //Logger.log(configStream.toString());
            FirebaseOptions options = new FirebaseOptions.Builder().setCredentials(GoogleCredentials.fromStream(configStream))
                    .setDatabaseUrl("https://otrack-55b36.firebaseio.com")
                    .build();
            FirebaseApp.initializeApp(options);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void message(Message message) {
        try{
            Database.datastore.save(message);
            JSONObject location = new JSONObject();
            location.put("coordinates", message.getCurrent_location());
            //System.out.println(location.toString());
            com.google.firebase.messaging.Message msg = com.google.firebase.messaging.Message.builder()
                    .putData("current_location", location.toString())
                    .setNotification(new Notification(message.getTitle(), message.getBody()))
                    .setTopic(message.getTopic())
                    .build();
            String response = FirebaseMessaging.getInstance().sendAsync(msg).get();
            System.out.println("FCM Message response: %s" + response);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
