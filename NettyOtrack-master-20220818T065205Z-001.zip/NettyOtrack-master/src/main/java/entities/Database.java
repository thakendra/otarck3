package entities;

import com.github.benmanes.caffeine.cache.*;
import com.mongodb.*;
import config.App;
import config.Mongo;
import dao.Vehicle;
import dev.morphia.Datastore;
import dev.morphia.Morphia;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;

import java.util.Arrays;

public class Database {
    final static Morphia morphia = new Morphia();


    static Datastore datastore;
    public static void initConnection(){
        morphia.mapPackage("dao");
        String mongoClientURI = "";
        if(Mongo.URL.equals("")){
            mongoClientURI = "mongodb://" + Mongo.USERNAME + ":" + Mongo.PASSWORD + "@" + Mongo.SERVER + ":" + Mongo.PORT + "/" + Mongo.DATABASE;
        }
        else {
            mongoClientURI = Mongo.URL;
        }
        System.out.println("Connection string: "  + mongoClientURI);
        datastore = morphia.createDatastore(new MongoClient(new MongoClientURI(mongoClientURI)), Mongo.DATABASE);
    }

    public static Datastore getDatabase(){
        return datastore;
    }

    public final static LoadingCache<String, Vehicle> vehicleCache =  Caffeine.newBuilder().maximumSize(100).writer(new CacheWriter<String, Vehicle>() {
        @Override
        public void write(@NonNull String key, @NonNull Vehicle value) {
//            System.out.println("Need to update database");
            datastore.merge(value);
        }

        @Override
        public void delete(@NonNull String key, @Nullable Vehicle value, @NonNull RemovalCause cause) {

        }
    }).build(key ->
         datastore.createQuery(Vehicle.class).filter("imed ==", key).first()
    );
}
