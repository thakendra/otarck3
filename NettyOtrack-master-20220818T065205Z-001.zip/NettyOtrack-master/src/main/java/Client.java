import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws Exception{
        //Constants.ADDRESS = "103.198.9.236";
        //Constants.ADDRESS = "35.178.12.26";
        String ADDRESS = "0.0.0.0";
        int PORT = 8081;
        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();
        String loginMessage = "$LOGIN,0001,354630077519300,kletrack;v10.0.1;89014103243473592290,10,#";
        //String loginMessage = "$LOGIN,0001,,kletrack;v10.0.1;89014103243473592290,10,#";
        String aliveMessage = "$ALIVE,0001,,0,10#";
        String geolocMessage = "$GEOLOC,0002,354630077519300,2;31122013;175424;N32.435676;E040.456787;054;1040;00000;12;001;99999;99999;350;15045,0000,10#\r";
        String tripMessage = "$TRIP,0003,354630077519200,31122013;175424;N32.435676;E040.456787;000;1040;192;12;001;99999;99999;31122013;165424;N32.435676;E040.456787;000;1040;192;12;001;99999;99999;120;105;50;15210;5436843543545;24;0;5;45;3,10,#\r";
        String idleMessage = "$IDLE,0003,354630077519300,31122013;175424;N32.435676;E040.456787;054;1040;192;12;001;99999;99999;120,10,#\r";
        String speedMessage = "$SPEED,0003,354630077519300,31122013;175424;N32.435676;E040.456787;054;1040;192;12;001;99999;99999;145;75,10,#\r";
        String newGeolocMessage = "$GEOLOC,2,989878767676563,IO;19072018;111749;N27.705370;E85.316330;;00000;168;002;0001;00002;00000;0;0;SL15,99;off,#\r";
        String newIdleMessage = "$IDLE,$117,994487025261401,IO;10092018;111157;N27.687930;E85.350510;003;01294;166;008;10001;00002;00002;0;502;;SL17;off,#\r";
        String newLoginMessage = "$LOGIN,1,354630077519300,geoTrack;v1.0.0b;,22072018;002515,#\r";
        String newTripMessage = "$TRIP,1528,504986924814099,10022019;044323;N41.068830;E28.809780;000;00071;270;000;10000;00005;00002;10042019;041620;N41.056320;E28.674320;000;00000;309;000;10000;00005;00002;1626;096;032;14840;0;27;12;131;42;42;,#\r";
        //String newAliveMessage = "$ALIVE,22,994487025261401,SL24,99;#\r";
        String newAliveMessage = "$ALIVE,134,354630077518062,SL24,99;,#\r";
        String newSpeedMessage = "$SPEED,3778,356525090009156,08102018;081055;N27.698790;E85.347670;011;01300;101;008;10001;00000;00000;028;89;SL14;,#\r";
        String CrashTripMessage = "$TRIP,2306,356525090001310,29112018;075517;N27.680200;E85.332030;000;01293;009;008;10000;00002;00000;;;;;;;;;10000;00002;00000;0;000;000;0;0;0;38;0;68;0;,#\r";
        String crashGeolocMessage = "$GEOLOC,1885,354630077519300,XS;;;;;;;;;10000;00000;00000;0;49295;;SL17;off,#";
        String LocalMsg = "$GEOLOC,194,356525090010162,2;03122018;111148;N27.690520;E85.303360;000;01291;279;008;10000;00005;00002;0;162;;SL18;,#";
        String arunNew = "$GEOLOC,7842,123456789012345,HC;22012019;173433;N27.708710;E85.315190;2;1301;355;11;00001;00000;00000;2;479177;;SL27;,#";
        String Arun = "$GEOLOC,1,1234567890123456,IO;4122018;065907;N27.682130;E85.341800;0;1294;189;8;00001;00000;00000;0;479201;;SL14;off,#";
        String failedMessage = "$GEOLOC,65085,909422142335857,3;21032019;020014;N27.708130;E85.341930;27;1315;97;7;00001;00000;00000;12;479133;;SL14;,#";
        String failedMessage2 = "$GEOLOC,65086,909422142335857,3;21032019;020017;N27.708110;E85.342080;24;1315;99;7;00001;00000;00000;15;479133;;SL14;,#";
        String fail = "$GEOLOC,5,356525090008562,2;01042019;162301;N27.687080;E85.330450;11;1283;197;9;00001;00000;00000;9;479281;;SL18;,#";

        do{
            Socket server = new Socket(ADDRESS, PORT);
            PrintWriter output = new PrintWriter(server.getOutputStream(),false);
            String message = aliveMessage;
            switch (choice){
                case 1:
                case 10:
                    message = newLoginMessage;
                    break;
                case 2:
                    message = aliveMessage;
                    break;
                case 3:
                    message = geolocMessage;
                    break;
                case 4:
                    message = tripMessage;
                    break;
                case 5:
                    message = idleMessage;
                    break;
                case 6:
                    message = speedMessage;
                    break;
                case 7:
                    message = crashGeolocMessage;
                    break;
                case 8:
                    message = newGeolocMessage;
                    break;
                case 9:
                    message =  newTripMessage;
                    break;
                case 11:
                    message = fail;
                    break;
                case 14:
                    message = failedMessage;
                    break;
                case 15:
                    message = failedMessage2;
                    break;
            }
            System.out.println(message);
//            Thread.sleep(2000);
            output.write(message);
            output.flush();
            choice = scanner.nextInt();
        }while (choice != 16);

    }
}
