package packets;

public class Packet {
    protected String message;
    private byte[] data;
    public Packet(){}
    public Packet(String message){
        this.message = message;
    }

    public Packet(byte[] data){
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return  this.getMessage();
    }

    protected void decode(){}

}
