package packets;

import dao.*;
import helper.Parser;
import model.DatabaseObject;
import org.joda.time.PeriodType;
import utils.Constants;
import utils.DateTimeUtils;
import utils.LocationUtils;

import javax.swing.text.Document;
import javax.xml.crypto.Data;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class YokayaPacket extends Packet {
    protected String mType;
    protected String mPacketNo;
    protected String mIMEI;
    protected String mPayload;

    public String vendor;
    public Object subPacket;

    public YokayaPacket(String message, String vendor) {
        super(message);
        this.decode();
        this.vendor = vendor;
    }

    public YokayaPacket(String mIMEI,String vendor,String mtype){
        this.vendor = vendor;
        this.mIMEI = mIMEI;
        this.mType = mtype;

    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public String getmType() {
        return mType;
    }

    public String getmPacketNo() {
        return mPacketNo;
    }

    public String getmIMEI() {
        return mIMEI;
    }

    public String getmPayload() {
        return mPayload;
    }

    public Object getSubPacket() {
        return subPacket;
    }

    public void setSubPacket(Object subPacket) {
        this.subPacket = subPacket;
    }

    @Override
    protected void decode() {
        int part = 0;
        int count = 1;
        for (int i = 1; i <= this.message.length(); i++) {
            boolean isDelimiter = this.message.charAt(i - 1) == ',';
            if (!isDelimiter) continue;
            if (part == 0) {
                this.mType = this.message.substring(1, i - 1);
                part++;
                count = i;
            } else if (part == 1) {
                mPacketNo = this.message.substring(count, i - 1);
                part++;
                count = i;

            } else if (part == 2) {
                mIMEI = this.message.substring(count, i - 1);
                mPayload = this.message.substring(i, this.message.length() - 1);
                break;
            }
        }

        System.out.println("Type: " + this.mType);
        System.out.println("IMEI: " + this.mIMEI);
        System.out.println("Payload:  " + this.mPayload);

        if(mType.equals(Constants.Yokaya.LOGIN)){
            subPacket = new LoginPacket(mPayload);
        } else if (mType.equals(Constants.Yokaya.GEOLOC)) {
            subPacket = new GeolocPacket(mPayload);
        }else if(mType.equals(Constants.Yokaya.TRIP)){
            subPacket = new TripPacket(mPayload);
        }else if(mType.equals(Constants.Yokaya.IDLE)){
            subPacket = new IdlePacket(mPayload);
        }else if(mType.equals(Constants.Yokaya.ALIVE)){
            subPacket = new AlivePacket(mPayload);
        }
    }

    public class LoginPacket extends Packet implements DatabaseObject{
        private String mSoftware;
        private String mVersion;
        private String mDate;
        private String mTime;

        public LoginPacket(String payload) {
            super(payload);
            this.decode();
        }

        public LoginPacket(){}

        public Login getMongoObject(){
            return new Login(mIMEI,mVersion,mSoftware);
        }

        @Override
        protected void decode() {
            super.decode();
            int part = 0;
            int count = 1;
            for (int i = 1; i < this.message.length(); i++) {
                boolean isDelimiter = this.message.charAt(i - 1) == ';';
                if (!isDelimiter) continue;
                if (part == 0) {
                    part++;
                    this.mSoftware = this.message.substring(0, i - 1);
                    count = i;
                } else if (part == 1) {
                    this.mVersion = this.message.substring(count, i - 1);
                    part++;
                    break;
                }
            }

            System.out.println("Software: " +  this.mSoftware);
            System.out.println("Version: " + this.mVersion);
        }

        public String getmPacketNo() {
            return mPacketNo;
        }
    }

    public  class AlivePacket extends Packet implements DatabaseObject{
        private String random;
        private String gsmSignalLevel;
        private Boolean ignition;
        private String batteryValue;
        private String numberOfSatellites;

        public String getGsmSignalLevel() {
            return gsmSignalLevel;
        }

        public void setGsmSignalLevel(String gsmSignalLevel) {
            this.gsmSignalLevel = gsmSignalLevel;
        }

        public Boolean getIgnition() {
            return ignition;
        }

        public void setIgnition(Boolean ignition) {
            this.ignition = ignition;
        }

        public String getBatteryValue() {
            return batteryValue;
        }

        public void setBatteryValue(String batteryValue) {
            this.batteryValue = batteryValue;
        }

        public String getNumberOfSatellites() {
            return numberOfSatellites;
        }

        public void setNumberOfSatellites(String numberOfSatellites) {
            this.numberOfSatellites = numberOfSatellites;
        }

        //        private String

        public AlivePacket(){}

        public AlivePacket(String payload){
            super(payload);
            this.decode();
        }

        public AlivePacket(String gsmSignalLevel, Boolean ignition, String batteryValue, String numberOfSatellites){
            this.gsmSignalLevel = gsmSignalLevel;
            this.ignition = ignition;
            this.batteryValue = batteryValue;
            this.numberOfSatellites = numberOfSatellites;
        }

        public Alive getMongoObject() {
            return new Alive(mIMEI);
        }

        @Override
        protected void decode() {
            super.decode();
            int part =0;
            int count = 1;
            for (int i = 1; i < this.message.length(); i++) {
                boolean isDelimiter = this.message.charAt(i - 1) == ';';
                if(!isDelimiter) continue;
                if(part == 0) {
                    part++;
                    random = message.substring(0, i -1);
                    count = 1;
                }else if(part == 1){
                    this.gsmSignalLevel = this.message.substring(count,i-1);
                    break;
                }
            }
        }
    }

    public class GeolocPacket extends Packet implements DatabaseObject {

        private String source;
        private String date;
        private String time;
        private String[] coordinates = new String[2];
        private Double latitude;
        private Double longitude;
        private String speed;
        private String altitude;
        private String direction;
        private String satelliteNumber;
        private String packageDistance;
        private String totalDistance;
        private String gsmSignalLevel;
        private String digitalEntries;
        private String analogEntry1;
        private String analogEntry2;
        private String maximumG;
        private String status = "on";
        private Boolean ignition = false;
        private String batteryValue;

        public String getSatelliteNumber() {
            return satelliteNumber;
        }

        public void setSatelliteNumber(String satelliteNumber) {
            this.satelliteNumber = satelliteNumber;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public Boolean getIgnition() {
            return ignition;
        }

        public void setIgnition(Boolean ignition) {
            this.ignition = ignition;
        }

        public String getBatteryValue() {
            return batteryValue;
        }

        public void setBatteryValue(String batteryValue) {
            this.batteryValue = batteryValue;
        }

        GeolocPacket(String payload){
            super(payload);
            this.decode();
        }

        public GeolocPacket(String date,String time,Double latitude, Double longitude, String speed, String direction, String totalDistance, String packageDistance, String altitude,String gsmSignalLevel, Boolean ignition, String batteryValue, String numberOfSatellites){
            this.date = date;
            this.time = time;
            this.latitude = latitude;
            this.longitude = longitude;
            this.coordinates[0] = latitude.toString();
            this.coordinates[1] = longitude.toString();
            this.speed = speed;
            this.direction = direction;
            this.totalDistance = totalDistance;
            this.packageDistance = packageDistance;
            this.altitude = altitude;
            this.satelliteNumber = numberOfSatellites;
            this.batteryValue = batteryValue;
            this.ignition = ignition;
            this.gsmSignalLevel = gsmSignalLevel;
        }

        public Geoloc getMongoObject(){
            return new Geoloc(mIMEI,
                    source,
                    DateTimeUtils.convertDateTime(date, time),
                    Arrays.asList(coordinates),
                    Double.parseDouble(speed.isEmpty()? "0":speed),
                    Integer.parseInt(altitude.isEmpty() ? "0" : altitude),
                    Double.parseDouble(direction.isEmpty()? "0" : direction),
                    Integer.parseInt(satelliteNumber.isEmpty() ? "0" : satelliteNumber),
                    Integer.parseInt(packageDistance.isEmpty() ? "0" : packageDistance),
                    Double.parseDouble(totalDistance.isEmpty() ? "0": totalDistance),
                    gsmSignalLevel);
        }

        public String getIMEI() { return  getmIMEI(); }

        public Double getmLat() {
            return latitude;
        }

        public Double getmLon() {
            return longitude;
        }

        public Double getSpeed() {
            return speed.isEmpty() ? 0 : Double.parseDouble(speed);
        }

        public Double getHeading() {
            return direction.isEmpty() ? 0 : Double.parseDouble(direction);
        }

        @Override
        protected void decode() {
            super.decode();
            int part = 0;
            int count = 1;
            for (int i = 1; i < this.message.length(); i++) {
                boolean isDelimiter = this.message.charAt(i - 1) == ';';
                if (!isDelimiter) continue;
                if (part == 0) {
                    this.source = this.message.substring(0, i - 1);
                    part++;
                    count = i;
                } else if (part == 1) {
                    this.date = this.message.substring(count, i - 1);
                    part++;
                    count = i;
                }else  if(part == 2){
                    this.time = this.message.substring(count, i - 1);
                    part++;
                    count = i;
                }else if(part == 3){
                    this.latitude = Double.parseDouble(LocationUtils.convertCoordinates(this.message.substring(count, i - 1)));
                    this.coordinates[1] = this.message.substring(count, i - 1);
                    part++;
                    count = i;
                }else if(part == 4) {
                    this.longitude = Double.parseDouble(LocationUtils.convertCoordinates(this.message.substring(count, i - 1)));
                    this.coordinates[0] = this.message.substring(count, i - 1);
                    part++;
                    count = i;
                }else if(part == 5) {
                    speed = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 6) {
                    altitude = this.message.substring(count, i-1);
                    part++;
                    count = i;

                }else if(part == 7) {
                    direction = this.message.substring(count, i -1);
                    part++;
                    count = i;
                }else if(part == 8) {
                    satelliteNumber = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 9) {
                    digitalEntries = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 10) {
                    analogEntry1 = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 11) {
                    analogEntry2 = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 12) {
                    packageDistance = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 13) {
                    totalDistance = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 14) {
                    maximumG = this.message.substring(count, i -1);
                    part++;
                    count = i;
                }else if(part == 15) {
                    gsmSignalLevel = this.message.substring(count, i -1);
                    part++;
                    count = i;
                }else if(part == 16) {
                    status = this.message.substring(count, i - 1);
                    break;
                }
            }
        }
    }

    public class IdlePacket extends Packet implements DatabaseObject {
        private String date;
        private String time;
        private String[] coordinates = new String[2];
        private String latitude;
        private String longitude;
        private String speed;
        private String altitude;
        private String direction;
        private String satelliteNumber;
        private String digitalInputs;
        private String analogInput1;
        private String analogInput2;
        private String violatedTime;
        private String gsmSignalLevel;
        private String source;
        private String distanceBetweenPackage;
        private String totalDistance;

        IdlePacket(String payload){
            super(payload);
            this.decode();
        }

        public Idle getMongoObject(){
            return new Idle(time, latitude, longitude, mIMEI);
        }

        @Override
        protected void decode() {
            super.decode();
            int count = 1;
            int part = 0;
            int length = this.message.length();
            for(int i =1; i<=length; i++){
                boolean isDelimiter = this.message.charAt(i -1 ) == ';' || this.message.charAt(i -1 ) == ',';
                if(!isDelimiter) continue;
                if(part == 0){
                    source = this.message.substring(0, i-1);
                    part++;
                    count = i;
                }else if(part == 1){
                    date = (this.message.substring(count , i-1));
                    part++;
                    count = i;
                }else if(part == 2){
                    time = (this.message.substring(count , i-1));
                    part++;
                    count = i;
                }else if(part == 3) {
                    coordinates[1] = this.message.substring(count, i - 1);
                    latitude = this.message.substring(count, i - 1);
                    part++;
                    count = i;
                }else if(part == 4) {
                    coordinates[0] = this.message.substring(count, i - 1);
                    longitude = this.message.substring(count, i - 1);
                    part++;
                    count = i;
                }else if(part == 5) {
                    speed = this.message.substring(count, i -1);
                    part++;
                    count = i;
                }else if(part == 6) {
                    altitude = this.message.substring(count, i-1);
                    part++;
                    count = i;
                }else if(part == 7) {
                    direction = this.message.substring(count, i -1);
                    part++;
                    count = i;
                }else if(part == 8) {
                    satelliteNumber = this.message.substring(count, i -1);
                    part++;
                    count = i;
                }else if(part == 9) {
                    digitalInputs = this.message.substring(count, i -1);
                    part++;
                    count = i;
                }else if(part == 10) {
                    analogInput1 = this.message.substring(count, i -1);
                    part++;
                    count = i;
                }else if(part == 11) {
                    analogInput2 = this.message.substring(count, i -1);
                    part++;
                    count = i;
                }else if(part == 12) {
                    violatedTime = this.message.substring(count, i -1);
                    part++;
                    count = i;
                }else if(part == 13) {
                    distanceBetweenPackage = this.message.substring(count, i -1);
                    part++;
                    count = i;
                }else if(part == 14) {
                    totalDistance = this.message.substring(count, i -1);
                    gsmSignalLevel = this.message.substring(i, length-1);
                    break;
                }
            }
        }
    }

   public class TripPacket extends Packet implements DatabaseObject{

        private String date;
        private String time;
        private String latitude;
        private String longitude;
        private String speed;
        private String altitude;
        private String direction;
        private String satelliteNumber;
        private String[] coordinates = new String[2];
        private String digitalInputs;
        private String analogInput1;
        private String analogInput2;
        private String initialDate;
        private String initialTime;
        private String initialLongitude;
        private String initialLatitude;
        private String initialSpeed;
        private String initialDirection;
        private String initialAltitude;
        private String initialSatelliteNumber;
        private String initialDigitalInputs;
        private String initialAnalogInputs1;
        private String initialAnalogInputs2;
        private String timePeriod;
        private String maximumSpeed;
        private String avgSpeed;
        private String totalSpeedTimeViolation;
        private String totalIdleTimeViolation;
        private String waitingTimeAfterIgnitionTurnedOn;
        private String totalIdleTime;
        private String waitingTimeBeforeIgnitionTurnedOff;
        private String gsmSignalLevel;
        private String distance;
        private String driverId;
        private String[] initialCoordinates = new String[2];

        TripPacket(String payload){
            super(payload);
            this.decode();
        }

       public TripPacket(String date,
                   String time,
                   String latitude,
                   String longitude,
                   String speed,
                   String altitude,
                   String direction,
                   String satelliteNumber,
                   String initialDate,
                   String initialTime,
                   String initialLatitude,
                   String initialLongitude,
                   String initialSpeed,
                   String initialDirection,
                   String initialAltitude,
                   String initialSatelliteNumber,
                   String maximumSpeed,
                   String avgSpeed,
                   String totalSpeedTimeViolation,
                   String totalIdleTimeViolation,
                   String waitingTimeAfterIgnitionTurnedOn,
                   String totalIdleTime,
                   String waitingTimeBeforeIgnitionTurnedOff,
                   String gsmSignalLevel,
                   String distance){
            this.date = date;
            this.time = time;
            this.altitude = altitude;
            this.speed = speed;
            this.coordinates[0] = latitude;
            this.coordinates[1] = longitude;
            this.direction = direction;
            this.satelliteNumber = satelliteNumber;
            this.initialDate = initialDate;
            this.initialTime = initialTime;
            this.initialCoordinates[0] = initialLatitude;
            this.initialCoordinates[1] = initialLongitude;
            this.initialSpeed = initialSpeed;
            this.initialDirection = initialDirection;
            this.initialAltitude = initialAltitude;
            this.initialSatelliteNumber = initialSatelliteNumber;
            this.timePeriod = DateTimeUtils.convertToLocalDateTime(initialDate,initialTime,date,time);
            this.maximumSpeed = maximumSpeed;
            this.avgSpeed = avgSpeed;
            this.totalSpeedTimeViolation = totalSpeedTimeViolation;
            this.totalIdleTimeViolation = totalIdleTimeViolation;
            this.waitingTimeAfterIgnitionTurnedOn = waitingTimeAfterIgnitionTurnedOn;
            this.totalIdleTime = totalIdleTime;
            this.waitingTimeBeforeIgnitionTurnedOff = waitingTimeBeforeIgnitionTurnedOff;
            this.gsmSignalLevel = gsmSignalLevel;
            this.distance = distance;

        }


        public Trip getMongoObject(){
            return new Trip(mIMEI,
                    DateTimeUtils.convertDateTime(date, time),
                    Arrays.asList(coordinates),
                    Integer.parseInt(speed.isEmpty()?"0":speed),
                    Integer.parseInt(altitude.isEmpty()?"0":altitude),
                    Integer.parseInt(direction.isEmpty()?"0":direction),
                    Integer.parseInt(satelliteNumber.isEmpty()?"0":satelliteNumber),
                    DateTimeUtils.convertDateTime(initialDate, initialTime),
                    Integer.parseInt(initialSpeed.isEmpty()?"0":initialSpeed),
                    Integer.parseInt(initialAltitude.isEmpty()?"0":initialAltitude),
                    Arrays.asList(initialCoordinates),
                    Integer.parseInt(initialDirection.isEmpty()?"0":initialDirection),
                    Integer.parseInt(initialSatelliteNumber.isEmpty()?"0":initialSatelliteNumber),
                    timePeriod.isEmpty()?"":timePeriod,
                    distance.isEmpty()?"":distance,
                    Integer.parseInt(maximumSpeed.isEmpty()?"0":maximumSpeed),
                    Integer.parseInt(avgSpeed.isEmpty()?"0":avgSpeed),
                    Integer.parseInt(totalSpeedTimeViolation.isEmpty()?"0":totalSpeedTimeViolation),
                    totalIdleTimeViolation.isEmpty()?"":totalIdleTimeViolation,
                    waitingTimeAfterIgnitionTurnedOn.isEmpty()?"":waitingTimeAfterIgnitionTurnedOn,
                    totalIdleTime.isEmpty()?"":totalIdleTime,
                    waitingTimeBeforeIgnitionTurnedOff.isEmpty()?"":waitingTimeBeforeIgnitionTurnedOff,
                    gsmSignalLevel.isEmpty()?"0":gsmSignalLevel);
            //return new Trip(initialTime, initialLatitude,initialLongitude, time, latitude, longitude, mIMEI);
        }

        @Override
        protected void decode() {
            super.decode();

            int count = 1;
            int part = 0;
            int length = this.message.length();
            for(int i =1; i<=length; i++){
                //System.out.println(Integer.toString(i)+"=>"+stripped.substring(i-1,i));
                boolean isDelimiter = this.message.charAt(i -1 ) == ';' || this.message.charAt(i -1 ) == ',';
                if(!isDelimiter) continue;
                if(part == 0){
                    date = this.message.substring(0, i-1);
                    part++;
                    count = i;

                }else if(part == 1){
                    time = (this.message.substring(count , i-1));
                    part++;
                    count = i;
                }else if(part == 2) {
                    coordinates[1] = this.message.substring(count, i - 1);
                    latitude = this.message.substring(count, i - 1);
                    part++;

                    count = i;

                }else if(part == 3) {
                    coordinates[0] = this.message.substring(count, i - 1);
                    longitude = this.message.substring(count, i - 1);
                    part++;
                    count = i;

                }else if(part == 4) {
                    speed = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 5) {
                    altitude = this.message.substring(count, i-1);
                    part++;
                    count = i;

                }else if(part == 6) {
                    direction = this.message.substring(count, i -1);
                    part++;
                    count = i;
                }else if(part == 7) {
                    satelliteNumber = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 8) {
                    digitalInputs = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 9) {
                    analogInput1 = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 10) {
                    analogInput2 = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 11) {
                    initialDate = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 12) {
                    initialTime = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 13) {
                    initialCoordinates[1] = this.message.substring(count, i -1);
                    initialLatitude = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 14) {
                    initialCoordinates[0] = this.message.substring(count, i -1);
                    initialLongitude = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 15) {
                    initialSpeed = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 16) {
                    initialAltitude = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 17) {
                    initialDirection = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 18) {
                    initialSatelliteNumber = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 19) {
                    initialDigitalInputs = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 20) {
                    initialAnalogInputs1 = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 21) {
                    initialAnalogInputs2 = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 22) {
                    timePeriod = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 23) {
                    maximumSpeed = this.message.substring(count, i -1);
                    //time1 = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 24) {
                    avgSpeed = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 25) {
                    distance = this.message.substring(count, i -1);
                    //approxSpeed = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 26) {
                    driverId = this.message.substring(count, i -1);
                    //time2 = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 27) {
                    totalSpeedTimeViolation = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 28) {
                    totalIdleTimeViolation = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 29) {
                    waitingTimeAfterIgnitionTurnedOn = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 30) {
                    totalIdleTime = this.message.substring(count, i -1);
                    part++;
                    count = i;

                }else if(part == 31) {
                    waitingTimeBeforeIgnitionTurnedOff = this.message.substring(count, i -1);
                    gsmSignalLevel = this.message.substring(i, length-1);
                    break;
                }
            }
        }
    }

}